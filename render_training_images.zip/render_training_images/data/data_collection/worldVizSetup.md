
# World Viz setup

The purpose is to describe setting up World Viz for data collection 

please be sure to record all settings in a config file (ex. __example_space_03_10_2020_000/motion_capture_settings.yaml__)

## Hardware setup
* Cameras with PoC ethernet. Connect to PC via USB dongle adapter
* Ethernet to network for VPRN
* PC with software, password: nokia
* USB cable for tag charging and parameter changing

## Main software
* PPT Studio N shortcut on desktop
* Choose 'File-> load factory defaults' to get proper windows

### Calibration
* Cameras panel on right, right-click on each camera's title bar and make sure "active" is checked. 
* Place calibration frame near origin.
* Click "Calibrate button"
* Click "Reset", then "Calibrate"

### Setting up markers
* Under Configuration, Post-process, choose Marker ID 32 plug-in. Check the number of markers desired.
* Turn on markers and bring into field of view. Make sure they are seen.

### Setting up rigid body
* Under Configuration, Post-process, choose Rigid body plug-in.
* Turn on at least 3 markers. 
* Click on "Acquire geometry" if necessary.

### Other plug-ins
* Under Configuration, Post-process, choose Ray visualization and Camera visualization


## Tag configuration software


