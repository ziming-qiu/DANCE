# Calibration and Coordinate Frame Alignment

Frames:
 - WorldVis
 - CalibScan
 - DataScan
 - MoCapHarness
 - CalibBoard
 - DeviceCamera

CameraParameters:
 - DeviceCamera
 - VirtualCamera

![TransformGraph](assets/TransformGraph.png "TransformGraph")  

Transform from from A to frame B at time $`t`$ is denoted as $`T^t_{AB}`$.  
Inverses exist, are unique, and can be written $`(T^t_{AB})^{-1} = T^t_{BA}`$.   
If $`T^t_{AB}`$ is fixed ($`T^t_{AB} = T^{t+1}_{AB}`$) we can omit the time and write $`T_{AB}`$.   

We want $`T^t_{0C}`$, but can't observe it directly.
Different measurement modalities yield different transforms
- WorldViz: $`T^t_{H0}`$, $`T^t_{M0}`$
- Leica/Scan: $`T^0_{MS}`$, $`T^0_{BS}`$
- Camera Calib: $`T^0_{BC}`$

We can then solve for $`T^t_{0C}`$ in terms of the other transforms:
1. $`T^t_{0C} = T^t_{0H} T_{HC}  `$ 
1. $`T^0_{0C} = T^0_{0H} T_{HC} = T_{0M} T_{MS} T_{SB} T_{BC}  `$  &nbsp;&nbsp;&nbsp; (setting $`t = 0`$)
1. $`T^0_{H0} T^0_{0C} = T^0_{HC} = T^0_{H0} T_{0M} T_{MS} T_{SB} T_{BC}  `$   
1. $`T^t_{0C} = T^t_{0H} T^0_{H0} T_{0M} T_{MS} T_{SB} T_{BC}  `$ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (subbing $`T^0_{HC}`$ from 3 into 1)


## Procedure

### Find Camera Intrinsics ($`K_R`$)
run `python ../scripts/calibrate.py 'device_calib_imgs/*/*.png' --rows 8 --cols 11 --square_size 0.6 --oufile transforms/intrinsics`

### Find $`T_{HC}`$

1. align CalibScan to WorldViz (compute $`T^0_{MS}`$)  
    - run `python align.py --scan calib_scan.pcd --points wv_markers.csv --outfile transforms/T0_MS` 
    - you will be asked to click on the WorldVis markers in the scan (it is very important that you select them in the same order that they appear in `wv_markers.csv`)
    - the pointcloud will be displayed. If the rendered orbs are aligned with the WV markers it worked. 
2. align board frame to CalibScan (compute $`T^0_{BS}`$)
    - run `python align.py --scan <calib_scan.pcd> --rows 8 --cols 11  --outfile transforms/T0_BS`
    - you will be asked to click all the internal checkerboard corners in the scan (it is very important that you select them starting from the top left as you face the board moving from left to right proceeding row by row top to bottom).
3. align camera frame to board frame (compute $`T^0_{CB}`$)
    - run `python ../scripts/find_extrinsic.py base_img.png transforms/intrinsics --rows 8 --cols 11 --square_size 0.6`

We can now compute

$`T^0_{HC} = T^0_{H0} T_{0M} T_{MS} T_{SB} T_{BC}`$,  

and subsequently  

$`T^t_{0C} = T^t_{0H} T_{HC}  `$. 

run `python ../scripts/combine_transforms.py transforms/`

or to do them all in a row run   

`python ../scripts/calib_system.py --points wv_markers.csv --scan calib_scan.pcd 
                            --rows 8 --cols 11 --base_img base_img.png 
                            --intrinsics transforms/intrinsics
                            --square_size 0.6 
                            --outfile transforms/`

You will then be able to load `transforms/T_HC.npy` to use to compute $`T^t_{0C}`$.

### Align DataScan to WorldViz
repeat the process used to align CalibScan to WorldViz with <data_scan.pcd>



