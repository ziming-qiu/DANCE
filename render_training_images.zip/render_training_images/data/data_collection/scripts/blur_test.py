import numpy as np
import glob
import json
import cv2
import matplotlib.pyplot as plt
import argparse
import pathlib
import sys
from tqdm import tqdm
import warnings
import multiprocessing as mp
import functools
import ioutils as io

def apply_motion_blur(image):
    # line kernel
    size = 4
    kernel = np.zeros((size, size))
    kernel[int((size-1)/2), :] = np.ones(size)
    kernel = kernel / size    
    blurry = cv2.filter2D(image, kernel=kernel, ddepth=cv2.CV_8U)
    return blurry

def apply_defocus_blur(image):
    kernel = np.ones((5,5), np.float32) / 25
    blurry = cv2.filter2D(image, kernel=kernel, ddepth=cv2.CV_8U)
    return blurry


def is_blurry(image, show:bool = False):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # NOTE: the derivative does nto fit into 8U therefore we need 16bit or 32bit integer. But because OpenCV cannot perform filter2D with int32, we use float32
    gray = gray.astype(np.float32)
    
    '''
    # plot histogram with 255 bins
    gray_vec = gray.flatten()
    b, bins, patches = plt.hist(gray_vec, bins=255)
    plt.xlim([0,255])
    plt.title("Grayscale histogram")
    plt.show()
    '''

    k_x = np.array([[ 1, -1]], dtype=np.float32)
    k_y = np.array([[ 1],
                    [-1]], dtype=np.float32)

    # larger receptive field
    k_x = np.array([[ 1, 0,-1],
                    [ 1, 0,-1],
                    [ 1, 0,-1]], dtype=np.float32)
    k_y = np.array([[ 1, 1, 1],
                    [ 0, 0, 0],
                    [-1,-1,-1]], dtype=np.float32)
    
    '''
    # Gabor kernel (steerable line detector)
    # We can do 8 of these and compare the statistics of each. 
    # If edges in a particular direction are missing, we have motion blur in the perpendicular direction
    #angle = 10
    #kernel = cv2.getGaborKernel((5, 5), 1.4, angle, 5, 1) # not a line but steerable
    '''


    '''
    # calculate histogram of the gray image
    vals = gray.flatten()
    counts, bins = np.histogram(vals, range(257))
    # plot histogram centered on values 0..255
    plt.bar(bins[:-1] - 0.5, counts, width=1, edgecolor='none')
    plt.xlim([-0.5, 255.5])
    plt.yscale( "log")
    plt.show()
    '''
    
    dx = cv2.filter2D(gray, kernel=k_x, ddepth=cv2.CV_32F)
    dy = cv2.filter2D(gray, kernel=k_y, ddepth=cv2.CV_32F)
    
    dx_vec = dx.flatten()
    min_x = np.min(dx_vec)
    max_x = np.max(dx_vec)
    mean_x = np.mean(dx_vec)
    std_x = np.std(dx_vec)
    hist_x, bins_x = np.histogram(dx_vec, density=False)
    #print('mean_x: ' + str(mean_x))
    #print('std_x: ' + str(std_x))

    dy_vec = dy.flatten()
    min_y = np.min(dy_vec)
    max_y = np.max(dy_vec)
    mean_y = np.mean(dy_vec)
    std_y = np.std(dy_vec)
    hist_y, bins_y = np.histogram(dy_vec, density=False)
    #print('mean_y: ' + str(mean_y))
    #print('std_y: ' + str(std_y))

    
    # generate Hyper-Laplacian distribution. Natual image gradients tend to follow this distribution with exponent ~0.6
    l_vec = np.random.laplace(loc=0.0, scale=1.0, size=dx_vec.shape) # NOTE: this is not a hyper-Laplacian but a Laplacian with a decay factor!
    l_vec = 255.0 * l_vec
    min_l = np.min(l_vec)
    max_l = np.max(l_vec)
    mean_l = np.mean(l_vec)
    std_l = np.std(l_vec)
    hist_l, bins_l = np.histogram(l_vec, density=False)
    #print(std_l)

    '''
    # Visualization
    plt.subplot(1,3,1)
    plt.hist(dx_vec, bins=512, range=(-256, 256), color='r')
    plt.yscale('log')
    plt.title("gradient histogram x")
    plt.subplot(1,3,2)
    plt.hist(dy_vec, bins=512, range=(-256, 256), color='b')
    plt.yscale('log')
    plt.title("gradient histogram y")
    plt.subplot(1,3,3)
    plt.yscale('log')
    plt.hist(l_vec, bins=512, range=(-256, 256), color='g')
    plt.title("gradient histogram hyper-Laplacian")
    plt.show()
    '''

    
    if show == True:
        mag = cv2.magnitude(dx, dy)
        mag_viz = cv2.normalize(mag, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8UC1)
        cv2.imshow("magnitude", mag_viz)

        dx_viz = np.absolute(dx)
        #dx_viz *= 255
        #dx_viz = cv2.normalize(dx, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8UC1)
        dx_viz = np.uint8(dx_viz)
        cv2.imshow("dx", dx_viz)

        dy_viz = np.absolute(dy)
        #dy *= 255
        #dy_viz = cv2.normalize(dy, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8UC1)
        dy_viz = np.uint8(dy_viz)
        cv2.imshow("dy", dy_viz)

        '''
        plt.subplot(2,2,1)
        plt.imshow(img)
        plt.title('Original'), plt.xticks([]), plt.yticks([])
        plt.subplot(2,2,2)
        plt.imshow(gray, cmap='gray')
        plt.title('gray'), plt.xticks([]), plt.yticks([])
        plt.subplot(2,2,3)
        plt.imshow(dx_viz)
        plt.title('|dx|'), plt.xticks([]), plt.yticks([])
        plt.subplot(2,2,4)
        plt.imshow(dy_viz)
        plt.title('|dy|'), plt.xticks([]), plt.yticks([])
        plt.show()
        '''

    # Heuristics:
    # gradients are significantly stronger in one direction
    if np.abs(std_x/std_y) > 1.3 or np.abs(std_x/std_y) < 0.7:
        # print("motion blur detected!")
        return True
    
    # low standard deviation
    std_thresh = 38.25 # = 255 * 15%
    if std_x < std_thresh and std_y < std_thresh:
        # print("defocus blur detected!")
        return True

    # TODO: A much better solution would be to measure the difference of the distributions from the hyper-Laplacian distribution.

    return False


def load_and_check( path: pathlib.Path, 
                    show: bool, 
                    wait: bool, 
                    bad_images_folder: pathlib.Path = None, 
                    good_images_folder: pathlib.Path = None) -> (pathlib.Path, bool):

    img = cv2.imread(str(path))

    blurry = is_blurry(img, show)

    if show == True:
        cv2.waitKey(0 if wait else 1)

    if bad_images_folder is not None and blurry:
        (bad_images_folder / path.name).symlink_to(path.resolve())
    if good_images_folder is not None and not blurry:
        (good_images_folder / path.name).symlink_to(path.resolve())

    return path, blurry


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_pattern', default=None, help='Input directory of the images to test')
    parser.add_argument('--output_dir', type=pathlib.Path, default=None, help='Output directory to place the results. One JSON file will be created. If not specified, the input directory will be used.')
    parser.add_argument('--output_file', default='blur_test_results.json', help='Output filename (JSON format, default is blur_test_results.json)')
    parser.add_argument('--show', default=False, action='store_true')
    parser.add_argument('--wait', default=False, action='store_true')
    parser.add_argument('--copy_images', default=False, action='store_true')

    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()

    if args.input_pattern is None:
        raise NotADirectoryError

    output_path = args.output_dir / args.output_file

    # find all images which match input pattern
    files = glob.glob(args.input_pattern) 

    print(f'found {len(files)} images in {args.input_pattern}')
    if len(files) == 0:
        sys.exit(0)


    # create folder to store blurry/non-blurry image symlinks
    good_images_folder = bad_images_folder = None
    if args.copy_images==True:
        good_images_folder = (args.output_dir / 'good_images')
        good_images_folder.mkdir(exist_ok=True) 
        
        bad_images_folder = (args.output_dir / 'bad_images')
        bad_images_folder.mkdir(exist_ok=True) 


    # setup function to load image and run blur check (to be mapped over paths)
    map_is_blurry = functools.partial(load_and_check, show=args.show, wait=args.wait,
                                        good_images_folder=good_images_folder, 
                                        bad_images_folder=bad_images_folder)
    result = {}
    bad_images = []
    good_images = []
    with mp.Pool() as pool:
        if args.show: file_iter = map(map_is_blurry, sorted(files)) # single core - sorted order
        else: file_iter = pool.imap_unordered(map_is_blurry, files) # mulicore - undefined order
        
        for path, blurry in tqdm(file_iter, total=len(files)):
            path = str(path) # needed because 'PosixPath' is not JSON serializable
            (bad_images if blurry else good_images).append(path)
            result[path] = blurry
 
    print(f'Blurry images: {len(bad_images)} / {len(files)} ({len(bad_images)/len(files) * 100:.2f} %)')

    print('Writing blur test results to ', output_path)
    args.output_dir.mkdir(exist_ok=True, parents=True)
    io.save(output_path, result, indent=4, sort_keys=True)

    good_images_output_path = output_path.parent / (output_path.stem + '_good' + output_path.suffix)
    io.save(good_images_output_path, good_images, indent=4, sort_keys=True)
    
    bad_images_output_path = output_path.parent / (output_path.stem + '_bad' + output_path.suffix)
    io.save(bad_images_output_path, bad_images, indent=4, sort_keys=True)

    cv2.destroyAllWindows()

