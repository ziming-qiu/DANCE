import argparse
from pathlib import Path
import open3d as o3d
import time

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pcd_path')
    parser.add_argument('--radius', type=float)
    parser.add_argument('--outpath',default=None)
    parser.add_argument('--headless', default=False, action='store_true')
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    print('loading pcd...', end='', flush=True)
    start = time.time()
    pcd = o3d.io.read_point_cloud(args.pcd_path)
    end = time.time()
    print(f'done ({end-start:.3f} s)', flush=True)

    print('downsampling pcd...', end='', flush=True)
    start = time.time()
    down_pcd = pcd.voxel_down_sample(args.radius)
    end = time.time()
    print(f'done ({end-start:.3f} s)', flush=True)

    if not args.headless:
        print('visualizing')
        o3d.visualization.draw_geometries([down_pcd], width=1280, height=800)


    if args.outpath is not None:
        print('saving downsampled pcd...', end='', flush=True)
        start = time.time()
        pcd_path = Path(args.pcd_path)
        o3d.io.write_point_cloud(args.outpath, down_pcd)
        end = time.time()
        print(f'done ({end-start:.3f} s)', flush=True)
