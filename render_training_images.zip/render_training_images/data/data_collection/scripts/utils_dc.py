import open3d as o3d 
import numpy as np
import cv2
import warnings
import pathlib
import json
import scipy.io
import glob

import ioutils as io


WORDVIZ_SCALE_FACTOR = 26.2/55

def pick_points(pcd):
    """Draw two point clouds after transformation.

    Parameters
    ----------
    source : o3d.PointCloud
        point cloud from which points have to be picked from

    Returns
    -------
    points : numpy.ndarray
        Points picked from the pcd

    """

    vis = o3d.visualization.VisualizerWithEditing()
    vis.create_window()
    vis.add_geometry(pcd)
    opt = vis.get_render_option()
    opt.background_color = np.asarray([0.5]*3)
    vis.run()  # user picks points
    vis.destroy_window()
    return vis.get_picked_points()



def check_repro(objpoints, imgpoints, rvecs, tvecs, K, dists):
    errors = []
    for i in range(len(objpoints)):
        imgpoints_hat, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], K, dists)
        error = cv2.norm(imgpoints[i],imgpoints_hat, cv2.NORM_L2) / len(imgpoints_hat)
        errors.append(error)

    print(f'mean error: {np.mean(errors):0.5f} pixels')

    return errors



def augment_with_cross(points, ii, jj):
    i, j = points[ii], points[jj]
    length = (np.linalg.norm(i) + np.linalg.norm(j)) / 2
    k = np.cross(i, j)
    k = length * k/np.linalg.norm(k)
    return np.concatenate((points, k[None,...]))


def solve_orthogonal(board_points, world_points):
    '''
    solves for rotation/reflection around the origin
    assumes no translation ie both board_points and world_points are aligned on the origin

    -- this may now be obsolete given that it is a special case of solve_affine
    '''

    # solve linear
    A, errs, rank, S = np.linalg.lstsq(
        board_points, 
        world_points, 
        rcond=None)

    # orthogonalize
    U, S, Vt = np.linalg.svd(A)
    R = U @ Vt

    # all singular values should be close to 1 because we know that the board_points and 
    # world points are already scaled correctly in meters 
    if not np.allclose(S, np.ones_like(S), rtol=0.04, atol=0.03):
        warnings.warn(f'all singular values should be close to 1 but are {S}', stacklevel=2)

    return R   


def solve_affine(A, B, allow_reflection=False):
    '''
    find affine transform (R, t) from A to B such that:
        $ ||(R @ A + t) - B|| is minimized $
    '''
    muA, muB = A.mean(axis=1), B.mean(axis=1)
    S0, S1 = (A.T - muA), (B.T - muB), 
    
    T, errs, rank, S = np.linalg.lstsq(S1, S0, rcond=None)
    U, S, Vt = np.linalg.svd(T)
    
    R = U @ Vt
    
    # do not allow reflection
    if not allow_reflection and np.linalg.det(R) < 0:
        R = U @ np.diag([1,1,-1]) @ Vt
    
    t = B.mean(1) - R@A.mean(1)
    
    return R, t[:, None]



    