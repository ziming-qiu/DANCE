import sampling
import ioutils as io
import cv2
import numpy as np
import argparse
import pathlib

def parse_args():
	parser = argparse.ArgumentParser()
	parser.add_argument('N', type=int)
	parser.add_argument('--seed', default=42, type=int)
	parser.add_argument('--limits_file', default=None)
	parser.add_argument('--outpath', default='.', type=pathlib.Path)

	args = parser.parse_args()
	return args

if __name__ == '__main__':

	args = parse_args()

	np.random.seed(args.seed); sampling.RANDOM_SEED = args.seed;

	sampling_kwargs = {} if args.limits_file is None else io.load(args.limits_file)

	Rs, ts = sampling.random_poses(N = args.N, **sampling_kwargs)

	args.outpath.mkdir(exist_ok=True, parents=True)
	io.save(args.outpath / 'tvecs.json', np.asarray(ts))
	io.save(args.outpath / 'rvecs.json', np.asarray([*map(lambda R : cv2.Rodrigues(R)[0], Rs)]))




