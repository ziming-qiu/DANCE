import open3d as o3d 
import argparse
import pathlib
import numpy as np
import cv2
import itertools
import warnings
import ioutils as io

import time

import threading

import copy

import matplotlib.pyplot as plt
from tqdm import tqdm

from data import render



def parse_args():
	parser = argparse.ArgumentParser()
	parser.add_argument('--pcd_path', default=None, help='path to point cloud')
	parser.add_argument('--voxel_size', default=0, type=float, help='size of voxel for downsampling. (0.01 => 1 point / cm^3)')
	parser.add_argument('--extrinsic_folder', help='path to folder where rvecs and tvecs are saved')
	parser.add_argument('--image_names', default=None)
	parser.add_argument('--image_path', default=None)
	parser.add_argument('--T_bs_folder', help='path to folder board to scan tranform is saved')
	parser.add_argument('--T_cloud', default=None)
	parser.add_argument('--rows', default=-1, type=int)
	parser.add_argument('--cols', default=-1, type=int)
	parser.add_argument('--point_size', default=1.5, type=float)
	parser.add_argument('--square_size', default=1, type=float)
	parser.add_argument('--intrinsic', default=None)
	parser.add_argument('--invert_poses', default=False, action='store_true')
	parser.add_argument('--headless', default=False, action='store_true')
	parser.add_argument('--max_images', default=float('inf'), type=float)
	parser.add_argument('--width', default=640, type=int)
	parser.add_argument('--height', default=360, type=int)
	parser.add_argument('--scene_coord_colors', default=False, action='store_true')
	parser.add_argument('--outpath', default=None)
	# parser.add_argument('--hide_frames', default=False, action='store_true')

	args = parser.parse_args()
	return args


def convert_to_scene_coord_colors(pcd):
	pnts_array = np.asarray(pcd.points)
	min, ptp = pnts_array.min(0), pnts_array.ptp(0)
	SC_colors = (pnts_array-min)/ptp
	pcd.colors = o3d.utility.Vector3dVector(SC_colors)
	return pcd


def vecs_to_mats(rvecs, tvecs):
	Rmats, _ = zip(*map(cv2.Rodrigues, rvecs))
	Rmats = np.asarray(Rmats)
	Ts = np.zeros((len(tvecs), 4,4))
	Ts[:, :3, :3], Ts[:, :3, 3], Ts[:, 3, 3] = Rmats, tvecs.squeeze(), 1

	return Ts


def createCoordFrames(Ts, size=1):
	return [*map(lambda T: o3d.geometry.TriangleMesh.create_coordinate_frame(
								size=size).transform(np.linalg.inv(T)),  Ts)]

def create_ball_grid(rows, cols, T_bs):
	board_points = np.stack(np.meshgrid(range(cols), range(rows), 0), -1).squeeze()
	board_points = board_points.reshape(cols*rows, 3) * args.square_size

	points = []
	normalizer = (board_points[-1]-board_points[0]).copy()
	normalizer[-1] = 1
	for bp in board_points:
		sp = o3d.geometry.TriangleMesh.create_sphere(radius=0.02, resolution=5)
		sp.translate(bp)
		sp.transform(T_bs)
		clr = bp / normalizer
		sp.paint_uniform_color([clr[0], clr[1], 0])
		points.append(sp)

	return points


from data.render import set_pose, get_pose
# def set_pose(vis, R_or_T, t=None):
# 	T = R_or_T
# 	if t is not None:
# 		T = np.eye(4)
# 		T[:3,:3], T[:3, 3], T[3,3] = R_or_T, t, 1
			
# 	ctr = vis.get_view_control()
# 	pose = ctr.convert_to_pinhole_camera_parameters()
# 	pose.extrinsic = T
# 	ctr.convert_from_pinhole_camera_parameters(pose)

# def get_pose(vis):
# 	ctr = vis.get_view_control()
# 	params = ctr.convert_to_pinhole_camera_parameters()
# 	return params.extrinsic

def show_image(path, window_name='image'):
	img = cv2.imread(str(path))
	cv2.imshow(window_name, img)
	cv2.waitKey(5)

def close_windows(*visualizers):
	[v.destroy_window() for v in visualizers if v]
	cv2.destroyAllWindows() 



class PoseViewer:
	def __init__(self, poses, vis_cam, vis_map, pose_marker, image_names=None, window_name='Image', headless=False):
		self.i = -1
		self.poses = poses
		self.image_names = None if image_names is None else io.load(args.image_names)
		self.window_name = window_name
		self.pose_marker = pose_marker
		self.vis_cam, self.vis_map = vis_cam, vis_map
		self.done = False
		self.frame_count = 0
		self.headless = headless

		#rotate 180
		if not headless:
			self.T_map = copy.copy(get_pose(vis_map))
			print(self.T_map)
			print(self.T_map[1, 3])
			self.T_map[1,1] *= -1
			self.T_map[1, 3] *= -1
			print(self.T_map[1, 3])
			print(self.T_map)

	def next_pose(self, vis=None):
		assert vis is None or vis == self.vis_cam, 'next_pose should only be called on cam'
		self.i += 1
		set_pose(self.vis_cam, self.poses[self.i%len(self.poses)])
		self.update_visualizer() 

		
	def prev_pose(self, vis=None):
		self.i -= 1
		set_pose(self.vis_cam, self.poses[self.i%len(self.poses)])
		self.update_visualizer() 

	def update_visualizer(self):
		T = get_pose(self.vis_cam)
		
		if not self.headless:
			self.vis_map.remove_geometry(self.pose_marker)
			# self.vis_cam.remove_geometry(self.pose_marker)
			self.pose_marker = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1
				).transform(np.linalg.inv(T))
			self.pose_marker.paint_uniform_color(np.zeros(3))
			self.vis_map.add_geometry(self.pose_marker)
			# self.vis_cam.add_geometry(self.pose_marker)
			# set_pose(self.vis_cam, T)
			set_pose(self.vis_map, self.T_map)

		render.configure_vis_window(vis_cam, intrinsic=args.intrinsic, 
							 background_color=mean_color, point_size=args.point_size)

		# vis_cam.update_geometry()
		if not self.headless: 
			vis_map.update_geometry()

			# kludge to make rendering smoother -- for some reason only v1 actually updates while you hold down a key
			v1, v2 = (vis_cam, vis_map) if self.frame_count % 2 == 0 else (vis_map, vis_cam) 
			if not (v1.poll_events() and v2.poll_events()):
				self.quit()

			vis_map.update_renderer()
		elif not vis_cam.poll_events(): 
			self.quit()
		vis_cam.update_renderer()
		self.frame_count += 1

		if not args.headless and args.image_names is not None and args.image_path is not None:
			show_image(
				pathlib.Path(args.image_path) / self.image_names[self.i%len(self.image_names)],
				window_name=self.window_name
			 )

	def capture_image(self, do_render=True):
		return np.asarray(
					vis_cam.capture_screen_float_buffer(do_render=do_render) )


	def quit(self, *args, **kwargs):
		self.done = True
		print('quit...')

		
if __name__ == '__main__':
	args = parse_args()

	if args.pcd_path is not None:
		pcd = o3d.io.read_point_cloud(args.pcd_path)

	e_f = pathlib.Path(args.extrinsic_folder)
	rvecs, tvecs = ( np.asarray(io.load(e_f / 'rvecs*')), 
					 np.asarray(io.load(e_f / 'tvecs*'))  )
	print(f'there are {len(tvecs)} poses')



	if args.T_bs_folder is not None:
		print('transforming poses')
		T = np.asarray(io.loadT(args.T_bs_folder))
	else:
		print('not transforming poses')
		T_bs = np.eye(4)


	if args.scene_coord_colors:
		pcd = convert_to_scene_coord_colors(pcd)


	if args.voxel_size:
		pcd = pcd.voxel_down_sample(voxel_size=args.voxel_size)

	if args.T_cloud is not None:
		T = np.asarray(io.load(args.T_cloud))
		pcd.transform(T)

	
	if args.invert_poses:
		Ts = np.linalg.inv(vecs_to_mats(rvecs, tvecs))
	else:
		Ts = vecs_to_mats(rvecs, tvecs)


	Ts = Ts @ np.linalg.inv(T_bs) # transform by T_bs_inv


	# frames = [] if args.hide_frames else createCoordFrames(Ts, size=0.3)
	frames = createCoordFrames(Ts, size=0.3)

	origin_scan = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1)
	origin_T = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1).transform(np.linalg.inv(T_bs))

	# render spheres for the checkerboard points
	cb_points = [] if args.rows==-1 and args.cols==-1 else create_ball_grid(args.rows, args.cols, T_bs)


	(w, h), (l, t) = (args.width, args.height), (100, 100)
	mean_color = np.asarray(pcd.colors).mean(0)

	# setup first person window
	vis_cam = o3d.visualization.VisualizerWithKeyCallback()
	vis_cam.create_window(width=w, height=h, left=l, top=t, window_name='Virtual Camera')
	render.configure_vis_window(vis_cam, intrinsic=args.intrinsic, 
						 background_color=mean_color, point_size=args.point_size)
	
	for p in (*cb_points, *([pcd] if args.pcd_path is not None else [])):
		vis_cam.add_geometry(p)

	if not args.headless:
		# setup overhead view
		vis_map = o3d.visualization.Visualizer()
		vis_map.create_window(width=int(1.5*w), height=int(1.5*w), left=l+w, top=t, window_name='Map')
		render.configure_vis_window(vis_map, background_color=mean_color, point_size=args.point_size)
	
	
		for p in (origin_scan, *frames, *cb_points, *([pcd] if args.pcd_path is not None else [])):
			vis_map.add_geometry(p)
	else:
		vis_map = None

	# create cv2 window to display images
	window_name = 'Real Camera'
	if not args.headless and args.image_names is not None and args.image_path is not None:
		cv2.namedWindow(window_name)
		cv2.moveWindow(window_name, l, l+2*h+25)


	pose_marker = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5).transform(get_pose(vis_cam))
	pose_marker = pose_marker.paint_uniform_color(np.zeros(3))
	

	pose_counter = PoseViewer(Ts, vis_cam, vis_map, 
								pose_marker=pose_marker, 
								image_names=args.image_names, 
								window_name=window_name,
								headless=args.headless)
	set_pose(pose_counter.vis_cam, Ts[0])
	pose_counter.update_visualizer()

	if args.outpath is None: # interactive

		pose_counter.vis_cam.register_key_callback(ord('K'), pose_counter.next_pose)
		pose_counter.vis_cam.register_key_callback(ord('J'), pose_counter.prev_pose)

		try:
			while not pose_counter.done:
				pose_counter.update_visualizer()

		except KeyboardInterrupt:
			print(KeyboardInterrupt('KeyboardInterupt... destroying windows'))

	else: # render
		# print('Render started.')
		ext = 'tiff' if args.scene_coord_colors else 'png'
		names = io.load(args.image_names) if args.image_names is not None else [f'{i}.{ext}' for i in range(len(Ts))]

		outpath = pathlib.Path(args.outpath)
		outpath.mkdir(exist_ok=True, parents=True)
		num_poses_to_render = min(len(Ts), args.max_images)
		with io.AsyncSaver(max_queue_size=max(int(0.12*num_poses_to_render), 100)) as saver:
			for i, (name, T) in enumerate(zip(names, tqdm(Ts, 
															initial=1,
															desc='rendering:',
														 	total=num_poses_to_render))):
				if pose_counter.done or i >= args.max_images: 
					tqdm.write('Quitting Render')
					break
				pose_counter.next_pose()
				pose_counter.update_visualizer()

				# name2 = (name.stem+'.tiff') if args.scene_coord_colors else name
				# tqdm.write(name)
				# print(name, name2, flush=True)
				# tqdm.write(name)
				# tqdm.write(name.split('.')[0]+'.tiff')

				img = pose_counter.capture_image(do_render=False)
				saver.save(outpath / name,  img)
			else:
				pass
				# print('Render finished.')
		
	close_windows(vis_cam, vis_map)






