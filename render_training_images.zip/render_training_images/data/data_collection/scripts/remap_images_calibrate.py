import glob
import argparse 
import cv2
import pathlib
import numpy as np

import ioutils as io

from tqdm import tqdm

def parse_args():
	parser = argparse.ArgumentParser()
	parser.add_argument('img_path')
	# parser.add_argument('--display', default=False, action='store_true')
	# parser.add_argument('--rows', default=8, type=int)
	# parser.add_argument('--cols', default=11, type=int)
	# parser.add_argument('--square_size', default=1, type=float)
	parser.add_argument('--verbose', default=False, action='store_true')
	parser.add_argument('--headless', default=False, action='store_true')
	parser.add_argument('--outpath', default=None)
	# parser.add_argument('--object_points', default=None)
	parser.add_argument('--intrinsic', default=None)
	parser.add_argument('--width', default=640, type=int)
	parser.add_argument('--height', default=360, type=int)
	parser.add_argument('--dists', default=None)
	parser.add_argument('--max_images', default=float('inf'), type=float)
	parser.add_argument('--exit_when_done', default=False, action='store_true')


	return parser.parse_args()


if __name__ == '__main__':
	args = parse_args()
	print(args)

	# get initial guess of camera intrinsic matrix
	K = np.asarray(io.load(args.intrinsic)).astype(np.float32)
	dists = np.asarray(io.load(args.dists)).astype(np.float32)


	K_new, valid_ROI = cv2.getOptimalNewCameraMatrix(K, dists, (args.width, args.height), alpha=1, centerPrincipalPoint=True)

	print(valid_ROI, valid_ROI[2]-valid_ROI[0], 'x', valid_ROI[3]-valid_ROI[1])

	print(dists)
	print(K)
	print(K_new)


	fixed = []

	if not args.headless:
		cv2.namedWindow('raw')
		cv2.namedWindow('undistorted')
		cv2.namedWindow('cropped')
		cv2.moveWindow('raw', 200, 360)
		cv2.moveWindow('undistorted', 200+640, 200)
		cv2.moveWindow('cropped', 200+640//2, 20+360+360)

	outpath = pathlib.Path(args.outpath)
	outpath.mkdir(parents=True, exist_ok=True)

	old_intrinsic_path = pathlib.Path(args.intrinsic).resolve()
	new_name = old_intrinsic_path.name
	new_folder_name = old_intrinsic_path.parent.name + '_undistorted'
	new_intrinsic_path = (old_intrinsic_path.parent.parent / 
							new_folder_name / new_name)
	print('>>>>>>>>>', new_intrinsic_path)
	new_intrinsic_path.parent.mkdir(parents=True, exist_ok=True)

	io.save(new_intrinsic_path, K_new)

	# with contextlib.redirect_stdout(sys.stdout if args.verbose else None):
	paths = sorted(glob.glob(args.img_path))
	for i, pth in enumerate(tqdm(paths, total=min(len(paths), args.max_images))):
		if i >= args.max_images:
			break
		# print(pth)
		pth = pathlib.Path(pth)
		im_in = cv2.imread(str(pth))
		im_out = cv2.imread(str(pth))
		im_out = cv2.undistort(im_in, K, dists, im_out, K_new)
		cv2.imwrite(str(outpath / pth.name), im_out)
		# fixed.append(im_out)

		if not args.headless:
			cv2.imshow('raw', im_in)
			cv2.imshow('undistorted', im_out)
			cv2.imshow('cropped', im_out[valid_ROI[1]:valid_ROI[3], valid_ROI[0]:valid_ROI[2]])
			cv2.waitKey(5)

	try:
		if not args.headless:
			cv2.imshow('raw', im_in)
			cv2.imshow('undistorted', im_out)
			cv2.imshow('cropped', im_out[valid_ROI[1]:valid_ROI[3], valid_ROI[0]:valid_ROI[2]])
			
			cv2.waitKey(10 if args.exit_when_done else 0)
	except KeyboardInterrupt as e:
		print(e)

	cv2.destroyAllWindows()

	# cv2.imwrite()


