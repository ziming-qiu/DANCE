import numpy as np
import cv2
import argparse
import glob



def draw(window_name, img):
    global points, mousex, mousey, state
    
    p_prev = None
    for i, p in enumerate(points):
        cv2.circle(img, p,5,(127,0,0),-1)
        if i % 2 == 1:
            cv2.line(img, p_prev, p, (0,60,0), 1)
        p_prev = p

    if state == cv2.EVENT_LBUTTONDOWN:
        if len(points) % 2 == 1:
            cv2.line(img, points[-1], (mousex,mousey), (0,100,0), 3)
        cv2.circle(img, (mousex,mousey),5,(0,0,255),1)

    cv2.imshow(window_name, img)
    cv2.waitKey(2)


def show(img, mtx, dist):
    h,  w = img.shape[:2]
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist ,(w,h) ,1 ,(w,h), centerPrincipalPoint=True)


    # undistort
    dst = cv2.undistort(img, mtx, dist, None, newcameramtx)

    # crop the image
    # x,y,w,h = roi
    # dst = dst[y:y+h, x:x+w]


    cv2.imshow('raw', img)
    cv2.moveWindow('raw', 200, 200)
    # cv2.imshow('undistorted', dst)

    
    print('press \'q\' to contine')
    while True:
        # try:
            # k = cv2.waitKey(1000)
        draw('undistorted', dst.copy())
        k = cv2.waitKey(100)
        if k != -1:
            break

        # except KeyboardInterrupt:
            # raise 

# points, mousex, mousey, state = [None,]*4
points = []
mousex, mousey = None, None
state = 'start'

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('pattern')
    args = parser.parse_args()


    ## all ks
    # dists = [[-0.05200775,  0.30339347, 0.00290703, -0.00520203, -0.49520822]]

    # K = [[  497.97572199,   0.,             327.3985533  ],
    #      [  0.,             497.97572199,   174.08612408 ],
    #      [  0.,             0.,             1.,          ]]


    ## k1, k2
    # dists = [[-0.04219796,  0.17064867 , 0.0058851 , -0.01228718 , 0.        ]]

    # K = [[496.92919851 ,  0. ,        316.20381354],
    #     [  0.,         496.92919851 ,180.55361898],
    #     [  0. ,          0.  ,         1.    ,    ]]



####### 0.1 focal, 

    dists = [[-0.42793929 , 0.42015229 , 0.01473508  ,0.01591308 , 0.        ]]

    K = [[720.99897396  , 0. ,        204.701236  ],
     [  0.       ,  720.99897396 ,282.52651887],
     [  0.       ,    0.     ,      1.        ]]



    dists, K = map(np.float32, (dists, K))
        
    print('dist coef:')
    print(dists, end='\n\n')
    print('intrinsic matrix')
    print(K, end='\n\n')


    # ----------------------------
    # ----------------------------

    # points = []
    # mousex, mousey = None, None
    # state = 'start'
    # window_name = 'calibrate'

    def mouse_callback(event,x,y,flags,param):
        global points, mousex, mousey, state
        mousex, mousey = x, y
        if (event == cv2.EVENT_LBUTTONDOWN or
              event == cv2.EVENT_LBUTTONUP or 
              event == cv2.EVENT_RBUTTONUP):
            state = event
        if event == cv2.EVENT_LBUTTONUP:
            points.append((x,y))
            print(f'appending ({x}, {y}) to points.')
        elif event == cv2.EVENT_RBUTTONUP:
            points.pop()

    # cv2.namedWindow('raw')
    # cv2.setMouseCallback('raw', mouse_callback)

    cv2.namedWindow('undistorted')
    cv2.setMouseCallback('undistorted', mouse_callback)

    for path in glob.glob(args.pattern):
        img = cv2.imread(path)
        show(img, K, dists)




