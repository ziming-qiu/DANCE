import numpy as np
import cv2
import glob
import time

import contextlib
import sys
import argparse
import pathlib

from utils_dc import check_repro
import ioutils as io

from show import show

import json

def process(img):
	return img # do nothing...



def calibrate(images, args, criteria):
	rows, cols = args.rows, args.cols

	# get coordinates of calib object points
	objp = None
	if args.object_points is None:
		# prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
		objp = np.zeros((rows*cols,3), np.float32)
		objp[:,:2] = np.mgrid[0:cols,0:rows].T.reshape(-1,2) * args.square_size
	else:
		objp = io.load(args.object_points, loader='json_numpy').astype(np.float32)

	# get initial guess of camera intrinsic matrix
	K_guess = None
	if args.intrinsic_guess is not None:
		K_guess = io.load(args.intrinsic_guess, loader='json_numpy').astype(np.float32)

	dists_guess = np.float32([0,0,0,0,0])
	if args.dists_guess is not None:
		dists_guess = io.load(args.dists_guess, loader='json_numpy').astype(np.float32)

	# Arrays to store object points and image points from all the images.
	objpoints = [] # 3d point in real world space
	imgpoints = [] # 2d points in image plane.

	if not args.headless:
		cv2.namedWindow("img")
		# cv2.namedWindow("img", cv2.WND_PROP_FULLSCREEN)
		# cv2.setWindowProperty("img",cv2.WND_PROP_FULLSCREEN,cv2.WINDOW_FULLSCREEN)

	gray = None
	good_imgs = []
	for fname in images:
		print(fname, end='...\t', flush=True)
		img = cv2.imread(fname)
		gray = process(img)
		gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)

		# Find the chess board corners
		ret, corners = cv2.findChessboardCornersSB(gray, (cols,rows), 
					cv2.CALIB_CB_ACCURACY+cv2.CALIB_CB_NORMALIZE_IMAGE+
					cv2.CALIB_CB_EXHAUSTIVE)

		# If found, add object points, image points (after refining them)
		wait_time = 5
		if ret:
			print('found', flush=True)
			objpoints.append(objp)

			# corners2 = corners
			corners2 = cv2.cornerSubPix(gray,corners,(3,3),(-1,-1),criteria)
			imgpoints.append(corners2)
			# Draw and display the corners
			# img = cv2.drawChessboardCorners(img, (cols,rows), corners2,ret)
			gray = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
			gray = cv2.drawChessboardCorners(gray, (cols,rows), corners2,ret)

			good_imgs.append(fname)
		else:
			print('not found', flush=True)

		if not args.headless:
			cv2.imshow('img',gray)
			cv2.waitKey(wait_time)

	cv2.destroyAllWindows()

	# f_guess = np.sqrt((np.asarray(img.shape)**2).sum())
	# f_guess = np.mean(img.shape)
	# K_guess = np.float32([
	#         [f_guess,  0,              f_guess/2  ], 
	#         [0,             f_guess,   f_guess/2  ], 
	#         [0,             0,              1,    ],
	#     ])

	print('\nattempting calibration', end=' ')
	# print('\nattempting calibration using K_guess = ')
	# print(K_guess)
	print(f'with {len(objpoints)} images each with {args.rows*args.cols} points for a total of',
		  f'{len(objpoints)*args.rows*args.cols} correspondences')

	# gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
	ret, K, dists, rvecs, tvecs = cv2.calibrateCamera(
		objpoints, imgpoints,
		imageSize=gray.shape[:2], distCoeffs=dists_guess,
		cameraMatrix=K_guess,
		flags =  
			cv2.CALIB_FIX_ASPECT_RATIO                                     +
			(0 if K_guess is None else cv2.CALIB_USE_INTRINSIC_GUESS)      +
			(   (cv2.CALIB_FIX_K1                                          +
					cv2.CALIB_FIX_K2                                       +
					cv2.CALIB_FIX_K3 ) if args.fix_dists else 0)           +
			cv2.CALIB_FIX_K4                                               +
			cv2.CALIB_FIX_K5                                               +
			cv2.CALIB_FIX_S1_S2_S3_S4                                      +
			(cv2.CALIB_FIX_TANGENT_DIST if args.fix_tangent_dist else 0)   +
			cv2.CALIB_ZERO_DISPARITY                                       +
			cv2.CALIB_FIX_K6
	)

	if ret:
		print('dist coefs:')
		print(dists, end='\n\n')
		print('intrinsic matrix')
		print(K, end='\n\n')
		print('ratio =', K[0,0]/K[1,1])

		print('\n')
		errors = check_repro(objpoints, imgpoints, rvecs, tvecs, K, dists)
		print('\n')
	
		if not args.headless:
			show(img, K, dists)
	else:
		print('failed')
	

	return ret, dists, K, rvecs, tvecs, errors, good_imgs


def parse_args():
	parser = argparse.ArgumentParser()
	parser.add_argument('img_path')
	parser.add_argument('--display', default=False, action='store_true')
	parser.add_argument('--fix_dists', default=False, action='store_true')
	parser.add_argument('--fix_tangent_dist', default=False, action='store_true')
	parser.add_argument('--rows', default=8, type=int)
	parser.add_argument('--cols', default=11, type=int)
	parser.add_argument('--square_size', default=1, type=float)
	parser.add_argument('--verbose', default=False, action='store_true')
	parser.add_argument('--headless', default=False, action='store_true')
	parser.add_argument('--outfile', default=None)
	parser.add_argument('--object_points', default=None)
	parser.add_argument('--intrinsic_guess', default=None)
	parser.add_argument('--dists_guess', default=None)
	parser.add_argument('--two_pass', default=False, action='store_true')

	args = parser.parse_args()

	if args.object_points is not None and args.intrinsic_guess is None:
		raise Exception(' '.join(('non-planar calibration rigs require --intrinsic_guess',
						'(for planar rigs OpenCV requires the coordinate system',
						'be rotated so Z==0 for all points)')))

	return args


if __name__ == '__main__':

	args = parse_args()
	
	metrics = {} # save metrics for tracking with dvc 

	# termination criteria
	criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

	with contextlib.redirect_stdout(sys.stdout if args.verbose else None):
		images = glob.glob(args.img_path)
		images.sort()

		
		ret, dists, K, rvecs, tvecs, errors, good_imgs = calibrate(images, args, criteria)



		if args.two_pass and ret:
			mean_error = np.mean(errors)
			metrics['first_pass_mean_reprojection_error'] = mean_error
			idx, rvecs_inliers, tvecs_inliers, errors_inliers = zip(*filter(lambda x: x[-1] < mean_error, zip(range(len(errors)), rvecs, tvecs, errors)))
			print(f'{len(tvecs_inliers)}/{len(tvecs)} images have reprojection error less than the mean')
			print('images\n\t', '\n\t'.join(str((good_imgs[i], np.round(errors[i], 3))) for i in (set(range(len(errors))) - set(idx))), 'are outliers\n')

			ret, dists, K, rvecs, tvecs, errors, good_imgs = calibrate([good_imgs[i] for i in idx], args, criteria)
		
		metrics['mean_reprojection_error'] = np.mean(errors)

	print()
	if ret and args.outfile is not None:
		pth = pathlib.Path(args.outfile)
		pth.mkdir(exist_ok=True)

		for v, lbl in zip(
			(dists, K, rvecs, tvecs), 
			('dists', 'K', 'rvecs', 'tvecs')):
			pth_str =  pth / f'{lbl}.json'
			io.save(pth_str, np.asarray(v))
			print('saving', pth_str)
		
		with pathlib.Path(f'metrics/{args.outfile}.json').open('w') as f:
			print(f)
			json.dump(metrics, f)

		# with pathlib.Path(f'metrics/{args.outfile}.json').open('r') as f:
		# 	print(*f.readlines())

	print() 







