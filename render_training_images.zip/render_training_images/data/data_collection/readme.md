# installation
1. if you don't already have it download and 
install [miniconda](https://docs.conda.io/en/latest/miniconda.html) (prefered)
or [anaconda](https://www.anaconda.com/distribution/)

2. clone this repo
with ssh (prefered):
```bash
git clone git@gitlab.com:bell-labs-jl/data-collection.git
```
or https
```bash
git clone https://gitlab.com/bell-labs-jl/data-collection.git
```

3. get a copy of `gcp_credential.json`

3. source setup script to create environment and set nessesary environment variables
```bash
source setup.sh 
```

# Data collection

The perpose of these instructions is to layout the process for collecting train/val/test data for semisupervised camera pose estimation using a Leica BLK 360, WorldVis, and a device-based camera (Cell Phone, Robot, etc.). 

Several sets of images will be gathered as well as a pair of RGBXYZ pointclouds. 

Follow best practices for each step! This is _essential_ to getting trustworthy data.
* [Camera Calibration](https://calib.io/blogs/knowledge-base/calibration-best-practices)
* [Scanning](https://www.youtube.com/watch?v=C-hechKBMXI)
* [Scanner Settings](https://support.matterport.com/hc/en-us/articles/360000650648-Scan-with-the-BLK360-Best-Practices#capture-with-the-blk360-0-1)

Upload all data as soon as you captue it following the correct format (Instructions TODO)

Data Folder Structure:

```
-name_of_space_mm_dd_yyyy_###
├─-device_calib_imgs
├─-calib_scan
├─-data_scan
├─-labeled_imgs
├─-unlabeled_imgs
├─-capture_settings.txt
```

## Capture Code (TODO)

## System Calibration
* please see [worldVizSetup.md](worldVizSetup.md) and [solveFrames.md](solveFrames.md)

## Equipment

* Leica BLK 360 (with tripod)
* Configured and calibrated Motion Capture system
* [Calibration Pattern](http://www.calib.io) (with stand / rigid mounts)
* Device Camera (Phone, Robot, etc.) (with rigid tripod/stand/mounts)
* [Tagged Motion Capture Harness for Device Camera](WorldVisHarness.md)  (with rigid tripod/stand/mounts)
* Proper Lighting (with rigid tripod/stand/mounts)

## Procedure

### Device Camera Setup
1. Fix all camera intrinsics -- make sure to turn off:  
    - autofocus  
    - zoom  
    - auto-brightness  
    - auto-white balance  
    - auto-everything/anything   
&nbsp;

2. Manually zoom/focus/balance/etc. the camera such that the images are in focus and apprear crisp, clear, and properly colored as it moves through the space where the data are to be gathered.  Record the settings you have used in your __device_camera_settings.yaml__ file ([see example here](example_space_03_10_2020_000/device_camera_settings.yaml)).
&nbsp;

3. Ensure that the clock of the camera is synced to the same NTP server as the Motion Capture System.

**Note**: It is imparative that you always use these settings when capturing data. All the other steps reley on this being accurate, precise, and reproduceable.

### Device Camera Calibration Data (TODO: see if we can do this with video)

[Camera Calibration Best Practices](https://calib.io/blogs/knowledge-base/calibration-best-practices)

1. Make sure the Motion Capture system is properly calibrated  

1. Affix Motion Capture markers to the four corners of the calibration pattern taking care that they will not move and that the centroid between the four markers is aligned with the center of the calibration pattern.

1. Make sure you are are using the same camera from [Device Camera Setup](#device-camera-setup) and using the settings in the __device_camera_settings.yaml__ file.

1. affix the Device Camera securely to the Motion Capture Harness so it is rigidly held in place and will not move with respect to the Harness.  

1. fix the Motion Capture Harness to the tripod/stand if applicable

1. follow best practices to capture a scan of the Device Camera, Motion Capture Harness, and Calibration Pattern (with markers affixed to the corners).

1. Do at least 12 times:  
    - place the Calibration Pattern such that it is rigid (not bent at all) with no glare on it on a stand or in a pose where it will not move or be bumped/disturbed.
    - place the camera on a tripod/stand/fixed base in a pose where it will not move or be bumped/disturbed.
    - use [check_calib_board.py](check_calib_board.py) to visualize the detection results and visually confirm that the calibration board (and each point within) is correctly dectected. If you cannot use [check_calib_board.py](check_calib_board.py) due to equimpment or other constrains please take many extra images. 

1. upload the scan to __name_of_space_mm_dd_yyyy_###/device_calib_scan__ all the images to the data folder __name_of_space_mm_dd_yyyy_###/device_calib_imgs__


### Scanning

Two registered scans of the whole space will need to be captured. One with several views of the calibration board, and one without the calibration board present. 

Each registered scan of the whole space will be composed of many sub-scans (each captured from a differant scanner pose). All the sub-scans will be assembled/registerd into a sigle unified scan in software as a post process. 

[Best Practices Scanning](https://www.youtube.com/watch?v=C-hechKBMXI)  
[Best Practices Scanner Settings](https://support.matterport.com/hc/en-us/articles/360000650648-Scan-with-the-BLK360-Best-Practices#capture-with-the-blk360-0-1)  

##### Tips:  
  - Take more scans than you think you need to
  - Make sure there is plenty of overlap between scans
  - Don't rush
  - Use high resolution
  - Follow best practices (see above)
  - Make sure nothing moves in between scans
  - Make sure the lighting doesn't change too much in between scans
  - Try to scan at a time when noone else needs the space so you don't feel pressure to rush
  - If the space is large enough / has multiple areas which are not in view of eachother, or if you have more than one Calibration Pattern try to capture the Calibration Pattern in multiple areas of the space 

##### Procedure:
1. place the Calibration Pattern such that it is rigid (not bent at all) with no glare on it on a stand or in a pose where it will not move or be bumped/disturbed.

1. follow best practices to scan the space

1. upload the scan to the data folder __name_of_space_mm_dd_yyyy_###/calib_scan__

1. remove the Calibration Pattern

1. follow best practices to scan the space a second time

1. upload the scan to the data folder __name_of_space_mm_dd_yyyy_###/data_scan__

### Val / Test Data Capture (TODO - See if we can do this with video)

1. Make sure the Motion Capture system is properly calibrated  

1. Make sure you are are using the same camera from [Device Camera Setup](#device-camera-setup) and using the settings in the __device_camera_settings.yaml__ file.

1. affix the Device Camera securely to the Motion Capture Harness so it is rigidly held in place and will not move with respect to the Harness.  

1. fix the Motion Capture Harness to the tripod/stand if applicable

1. Do approximately 1000 times:  
    - move the Device Camera  
    - ensure Motion Capture pose estimates have stabilized  
    - capture an image  

1. upload the scan to the data folder __name_of_space_mm_dd_yyyy_###/labeled_imgs__

### Train Data Capture (TODO - See if we can do this with video)

1. Make sure you are are using the same camera from [Device Camera Setup](#device-camera-setup) and using the settings in the __device_camera_settings.yaml__ file.  

1. Do approximately 10000 times:  
    - move the Device Camera  
    - capture an image  

1. upload the scan to the data folder __name_of_space_mm_dd_yyyy_###/unlabeled_imgs__



