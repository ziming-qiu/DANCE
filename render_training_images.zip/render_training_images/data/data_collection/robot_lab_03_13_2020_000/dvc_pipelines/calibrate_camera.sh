dvc run -f stages/transforms_camera_calib.dvc   \
        -d ../scripts/calibrate.py              \
        -d device_calib_imgs/moving_board       \
        -d device_calib_imgs/static_board       \
        -O transforms_camera_calib              \
        -M metrics/transforms_camera_calib.json \
        "python ../scripts/calibrate.py 'device_calib_imgs/*/*.png' --rows 8 --cols 11 --square_size 0.06 --two_pass --outfile transforms_camera_calib --headless"

git add transforms_camera_calib
git add stages/transforms_camera_calib.dvc
git add metrics/transforms_camera_calib.json 
