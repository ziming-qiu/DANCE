#!/bin/bash

create_pipeline() {
    NUM_PER_BATCH="$1"
    SEED="$2"

    echo "num_per_batch: $NUM_PER_BATCH, seed: $SEED"

    dvc run -f "stages/generate_random_poses/generate_random_poses"$SEED".dvc"  \
                    -d rendered_images/limits.json                              \
                    -d ../scripts/generate_random_poses.py                      \
                    -O rendered_images/poses/$SEED/tvecs.json                   \
                    -O rendered_images/poses/$SEED/rvecs.json                   \
                    --no-exec                                                   \
                "python ../scripts/generate_random_poses.py $NUM_PER_BATCH      \
                        --seed $SEED                                            \
                        --limits_file rendered_images/limits.json               \
                        --outpath rendered_images/poses/$SEED/"
}

if [ -z $1 ]; then
    printf 'please specify how many batches\n'
elif [ -z $2 ]; then
    printf 'please specify how many images per batch\n'
else
    NUM_BATCHES="$1"
    NUM_PER_BATCH="$2"

    mkdir -p stages/generate_random_poses
    if [[ "$NUM_BATCHES" == 0 ]]; then
        if [ -z $2 ]; then
            echo "please specify num per batch"
        elif [ -z $3 ]; then
            echo "please specify batch index"
        else
            BATCH_INDEX="$3"
            create_pipeline $NUM_PER_BATCH $BATCH_INDEX 
        fi
    else
        for i in $(seq 0 $[ $NUM_BATCHES - 1 ]); do
            create_pipeline  $NUM_PER_BATCH $i
            # git add rendered_images/poses/$i/tvecs.json
            # git add rendered_images/poses/$i/rvecs.json
        done
    fi
fi
