
dvc run -f stages/scale_intrinsic.dvc                   \
        -d transforms_camera_calib_undistorted/K.json   \
        -O transforms_camera_calib_undistorted/K_half_scale.json    \
        -O transforms_camera_calib_undistorted/K_quater_scale.json    \
        -O transforms_camera_calib_undistorted/K_eigth_scale.json    \
    python -c "import numpy as np; import ioutils as io; 
K=np.asarray(io.load('transforms_camera_calib_undistorted/K.json'));
[io.save(f'transforms_camera_calib_undistorted/K_{frac}_scale.json', K / 2**d) 
                  for d, frac in enumerate('half quater eigth'.split(), start=1)];"

	git add transforms_camera_calib_undistorted/K_eigth_scale.json
	git add stages/scale_intrinsic.dvc  