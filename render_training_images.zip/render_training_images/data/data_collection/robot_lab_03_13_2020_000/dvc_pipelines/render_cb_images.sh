
yes | dvc run -f stages/render_cb_images_wv.dvc                 \
        -d ../scripts/visualize_poses.py                        \
        -d transforms_camera_calib_undistorted/K.json           \
        -d from_matlab/calib/converted/wv                  \
        -d calib_scan/200313robotlab-cb-4mb_2.pts               \
        -d Transform_Scan2WV.mat                                \
        -d from_matlab/calib/converted/image_paths.json    \
        -d device_calib_imgs/undistorted/static_board           \
        -o device_calib_imgs/rendered/wv/static_board           \
    "python ../scripts/visualize_poses.py                                \
        --intrinsic transforms_camera_calib_undistorted/K.json           \
        --extrinsic_folder from_matlab/calib/converted/wv           \
        --pcd_path calib_scan/200313robotlab-cb-4mb_2.pts --invert_poses \
        --T_cloud Transform_Scan2WV.mat                                  \
        --image_names from_matlab/calib/converted/image_paths.json  \
        --image_path device_calib_imgs/undistorted/static_board          \
        --headless                                                  \
        --outpath device_calib_imgs/rendered/wv/static_board           &&\
    printf '\n\nTo track all the changes with git, run:\n\n\
        git add ../scripts/visualize_poses.py \
device_calib_imgs/rendered/wv/.gitignore dvc_pipelines/render_cb_images.sh\n\n AND '" #&

# render_cb_images_wv_pid=$!

dvc run -f stages/render_cb_images_cb.dvc                       \
        -d ../scripts/visualize_poses.py                        \
        -d transforms_camera_calib_undistorted/K.json           \
        -d from_matlab/calib/converted/cb                  \
        -d calib_scan/200313robotlab-cb-4mb_2.pts               \
        -d Transform_Scan2WV.mat                                \
        -d from_matlab/calib/converted/image_paths.json    \
        -d device_calib_imgs/undistorted/static_board           \
        -o device_calib_imgs/rendered/cb/static_board           \
    "python ../scripts/visualize_poses.py                                \
        --intrinsic transforms_camera_calib_undistorted/K.json           \
        --extrinsic_folder from_matlab/calib/converted/cb           \
        --pcd_path calib_scan/200313robotlab-cb-4mb_2.pts --invert_poses \
        --T_cloud Transform_Scan2WV.mat                                  \
        --image_names from_matlab/calib/converted/image_paths.json  \
        --image_path device_calib_imgs/undistorted/static_board          \
        --headless                                                  \
        --outpath device_calib_imgs/rendered/cb/static_board           &&\
    printf '\n\nTo track all the changes with git, run:\n\n\
        git ../scripts/visualize_poses.py \
device_calib_imgs/rendered/cb/.gitignore dvc_pipelines/render_cb_images.sh\n\n AND '"


# wait $render_cb_images_wv_pid

git add ../scripts/visualize_poses.py 
git add dvc_pipelines/render_cb_images.sh
git add device_calib_imgs/rendered/wv/.gitignore    
git add device_calib_imgs/rendered/cb/.gitignore    
git add stages/render_cb_images_cb.dvc
git add stages/render_cb_images_wv.dvc
