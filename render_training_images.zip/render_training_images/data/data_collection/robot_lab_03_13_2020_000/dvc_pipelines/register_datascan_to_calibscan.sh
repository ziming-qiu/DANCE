# downsample pointclouds
dvc run -f stages/downsample_calib_scan.dvc                             \
        -d ../scripts/downsample_pcd.py                                 \
        -d calib_scan/200313robotlab-cb-4mb_2.pts                       \
        -o calib_scan/200313robotlab-cb-4mb_2_downsampled.pts           \
    "python ../scripts/downsample_pcd.py                                \
        --pcd_path calib_scan/200313robotlab-cb-4mb_2.pts               \
        --radius 0.05                                                   \
        --headless                                                      \
        --outpath calib_scan/200313robotlab-cb-4mb_2_downsampled.pts"   

    git add stages/downsample_calib_scan.dvc calib_scan/.gitignore


dvc run -f stages/downsample_data_scan.dvc                              \
        -d ../scripts/downsample_pcd.py                                 \
        -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts                           \
        -o data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts               \
    "python ../scripts/downsample_pcd.py                                \
        --pcd_path data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts                   \
        --radius 0.05                                                   \
        --headless                                                      \
        --outpath data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts"       


    git add stages/downsample_data_scan.dvc data_scan/.gitignore


# # roughly align pointclouds (rotate datascan by pi/2 radians around the x axis)
# dvc run -f stages/roughly_align_data_calib_scan.dvc                     \
#         -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts               \
#         -o data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts       \
#     python -c "import numpy as np; from pyquaternion import Quaternion; \
#     import open3d as o3d;                                               \
#     T = Quaternion(axis=[1,0,0], angle=-np.pi/2).transformation_matrix; \
#     o3d.io.write_point_cloud(                                           \
#         'data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts',       \
#          o3d.io.read_point_cloud('data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts').transform(T))"


# use ICP to refine alignment
dvc run -f stages/register_pointclouds.dvc                              \
        -d ../scripts/register_pointclouds.py                           \
        -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts       \
        -d calib_scan/200313robotlab-cb-4mb_2_downsampled.pts           \
        -O transform_calib_scan_to_data_scan.json                       \
    python ../scripts/register_pointclouds.py                           \
                data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts  \
                calib_scan/200313robotlab-cb-4mb_2_downsampled.pts      \
                --headless --outpath transform_calib_scan_to_data_scan.json

git add ../scripts/register_pointclouds.py
git add ../scripts/downsample_pcd.py
git add stages/roughly_align_data_calib_scan.dvc
git add stages/register_pointclouds.dvc
git add transform_calib_scan_to_data_scan.json
git add dvc_pipelines/register_datascan_to_calibscan.sh





