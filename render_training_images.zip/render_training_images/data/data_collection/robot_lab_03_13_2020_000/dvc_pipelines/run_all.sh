# printf "\n# running dvc pull: \n"
# dvc pull 

printf "\n# calibrate_camera: \n"
source dvc_pipelines/calibrate_camera.sh

printf "\n# convert_from_matlab: \n"
source dvc_pipelines/convert_from_matlab.sh 

printf "\n# undistort cb images: \n"
source dvc_pipelines/undistort_images.sh 

printf "\n# render cb images: \n"
source dvc_pipelines/render_cb_images.sh

make_graph() { dvc pipeline show stages/"$1".dvc --dot | dot -Tpng > ../assets/pipelines/"$1".png; }

# make_graph() { dvc pipeline show "$1" --dot | dot -Tpng; }
# save_graph() { make_graph "$1" > "$2"; } # $1=path/to/some_stage.dvc, $2=path/to/somestage.png
# show_graph_mac() { make_graph "$1" | open -a Preview.app -f; } 


# dvc repro stages/render_cb_images_cb.dvc
# dvc repro stages/render_cb_images_wv.dvc
make_graph render_cb_images_cb
make_graph render_cb_images_wv
printf "\n# Render using CB Poses\n  ![From CB](../../assets/pipelines/render_cb_images_cb.png 'From CB')  \n\n" > dvc_pipelines/readme.md 
printf "\n# Render using WV Poses\n  ![From WV](../../assets/pipelines/render_cb_images_wv.png 'From WV')  \n\n" >> dvc_pipelines/readme.md 
git add ../assets/pipelines/render_cb_images_cb.png
git add ../assets/pipelines/render_cb_images_wv.png

printf "\n# decompress datascan: \n"
# decompress datascan
source dvc_pipelines/decompress_datascan.sh 

# render register datascan to calib scan
printf "\n# register_datascan_to_calibscan: \n"
source dvc_pipelines/register_datascan_to_calibscan.sh

# dvc repro stages/register_pointclouds.dvc
make_graph register_pointclouds
printf "\n# Register Pointcloud\n  ![Register Data to Calib Scan](../../assets/pipelines/register_pointclouds.png 'register pointclouds')  \n\n" >> dvc_pipelines/readme.md 


git add ../assets/pipelines/register_pointclouds.png


# decompress labled images
printf "\n# decompress labled images: \n"
source dvc_pipelines/decompress_labeled_images.sh
source dvc_pipelines/render_wv_images.sh

make_graph render_wv_images
printf "\n# Render WV (labled) Images\n  ![Render WV Images](../../assets/pipelines/render_wv_images.png 'render wv images')  \n\n" >> dvc_pipelines/readme.md 

git add dvc_pipelines/decompress_labeled_images.sh
git add dvc_pipelines/render_wv_images.sh
git add rendered_images/poses
git add ../assets/pipelines/render_wv_images.png


# generate images from random poses
# printf "\n# generate_random_poses: \n"
# source dvc_pipelines/generate_random_poses.sh
# printf "\n# render_random_images: \n" 
# source dvc_pipelines/render_random_images.sh

printf "\n# generate small batch random poses: \n"
RANK=999999999
NUM_IMAGES=100
source dvc_pipelines/generate_random_poses_batches.sh 0 $NUM_IMAGES $RANK       
source dvc_pipelines/render_random_images_in_batches.sh 0 $RANK       
source dvc_pipelines/render_random_scene_coord_images_in_batches.sh 0 $RANK       
  
dvc repro -s --force stages/generate_random_poses/generate_random_poses"$RANK".dvc && 
	dvc repro --downstream stages/generate_random_poses/generate_random_poses"$RANK".dvc

git add rendered_images/poses/"$RANK"
git add stages/generate_random_poses/
git add stages/render_random_images/
git add stages/render_random_images_scr/

# make_graph render_random_images
# printf "\n# Render Random Images\n  ![Render Random Images](../../assets/pipelines/render_random_images.png 'render random images')  \n\n" >> dvc_pipelines/readme.md 

# git add stages/generate_random_poses.dvc
# git add stages/render_random_images.dvc
# git add ../assets/pipelines/render_random_images.png
# git add dvc_pipelines/generate_random_poses.sh
# git add dvc_pipelines/render_random_images.sh

# check blurryness
printf "\n# blur_test: \n"
source dvc_pipelines/blur_test.sh
make_graph blur_test_data0
make_graph blur_test_data1
make_graph blur_test_data2
printf "\n# Blur Test\n  ![Blur Test Data 0](../../assets/pipelines/blur_test_data0.png 'blur test data 0')  \n\n" >> dvc_pipelines/readme.md 
printf "\n ![Blur Test Data 1](../../assets/pipelines/blur_test_data1.png 'blur test data 1')  \n\n" >> dvc_pipelines/readme.md 
printf "\n ![Blur Test Data 2](../../assets/pipelines/blur_test_data2.png 'blur test data 2')  \n\n" >> dvc_pipelines/readme.md 

git add ../assets/pipelines/blur_test_data*.png


# track readme and self
git add dvc_pipelines/readme.md 
git add dvc_pipelines/run_all.sh






