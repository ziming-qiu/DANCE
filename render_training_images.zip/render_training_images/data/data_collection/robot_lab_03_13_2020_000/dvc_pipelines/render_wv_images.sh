# # undistort
# dvc run -f stages/remap_labeled_images.dvc                      \
#         -d transforms_camera_calib                      \
#         -d ../scripts/remap_images_calibrate.py         \
#         -d labeled_images/images/data0               \
#         -o labeled_images/undistorted/data0   \
#     "python ../scripts/remap_images_calibrate.py 'labeled_images/images/data0/*.png'  \
#                 --intrinsic transforms_camera_calib/K.json                  \
#                 --dists transforms_camera_calib/dists.json                  \
#                 --outpath labeled_images/undistorted/data0      \
#                 --max_images 200                                    \
#                 --headless                                      \
#                 --exit_when_done"

# convert poses and valid image paths from matlab
dvc run -f stages/convert_from_matlab_labeled.dvc   \
        -d from_matlab/labeled_images/200416dat_camPoseRobotBatch1.mat                 \
        -d from_matlab/labeled_images/200416dat_camPoseRobotBatch2.mat                 \
        -d from_matlab/labeled_images/200416dat_camPoseRobotBatch3.mat                 \
        -o from_matlab/labeled_images/converted/camPoseWv/               \
    python -c "from pathlib import Path;  import ioutils as io; import numpy as np; import cv2;
basepath = Path('from_matlab/labeled_images/') ;
for i in range(1,4): 
    pth = basepath / f'200416dat_camPoseRobotBatch{i}.mat' ;
    md = io.load(pth) ;
    [io.save(k+'.json', v.transpose((2,0,1))) for k,v in md.items() if k in ('camPoseWv', 'WvSyncNew')]   ;
    valid_ind = md['frameIndValid'][:,0] ;
    #
    T = np.asarray(md['camPoseWv']).transpose((2,0,1))
    R, tvecs = T[:, :3, :3], T[:, :3, 3] ; 
    pth=Path(f'from_matlab/labeled_images/converted/camPoseWv/{i-1}/');
    pth.mkdir(exist_ok=True, parents=True)
    #
    names = ['_'.join(Path(u[0]).name.split(':')) for u in md['imageFileNamesBatch'][:, 0]] ;
    filtered_names = [names[i-1] for i in valid_ind]
    out_folder = (basepath / f'converted/{i-1}')
    out_folder.mkdir(exist_ok=True, parents=True) ;
    io.save(out_folder / 'image_paths.json', filtered_names) ;
    #
    io.save(out_folder / 'rvecs.json', np.asarray([cv2.Rodrigues(x)[0] for i, x in enumerate(R, start=1) if i in set(valid_ind)])); 
    io.save(out_folder / 'tvecs.json', tvecs[valid_ind-1]) ;"


git add stages/convert_from_matlab_labeled.dvc

# render images from point cloud
dvc run -f stages/render_wv_images.dvc                 \
        -d ../scripts/visualize_poses.py                        \
        -d transforms_camera_calib_undistorted/K.json           \
        -d from_matlab/calib/converted/wv                       \
        -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts         \
        -d Transform_Scan2WV.mat                                \
        -d from_matlab/labeled_images/converted/0/image_paths.json         \
        -d labeled_images/undistorted/data0           \
        -o labeled_images/rendered/data0           \
    "python ../scripts/visualize_poses.py                                \
        --intrinsic transforms_camera_calib_undistorted/K.json           \
        --extrinsic_folder from_matlab/labeled_images/converted/0           \
        --pcd_path data_scan/200313robotlabMerged_redSpotOrigin_noCropping_downsampled.pts \
        --invert_poses \
        --T_cloud Transform_Scan2WV.mat                                  \
        --image_names from_matlab/labeled_images/converted/0/image_paths.json  \
        --image_path labeled_images/undistorted/data0          \
        --max_images 50                                    \
        --headless                                          \
        --outpath labeled_images/rendered/data0  "

git add ../scripts/visualize_poses.py 
git add dvc_pipelines/render_wv_images.sh
git add stages/render_wv_images.dvc
