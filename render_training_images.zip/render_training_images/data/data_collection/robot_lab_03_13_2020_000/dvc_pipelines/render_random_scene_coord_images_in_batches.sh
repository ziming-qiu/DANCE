#!/bin/bash


# if [ -z $1 ]; then
#     printf 'please specify how many batches\n'
# else
#     mkdir -p stages/render_random_images
#     # render images from point cloud

#     for i in $(seq 0 $[$1-1]); do
#         mkdir -p rendered_images/rendered/$i

#         dvc run -f "stages/render_random_images/render_random_images"$i".dvc"                 \
#                 -d ../scripts/visualize_poses.py                        \
#                 -d transforms_camera_calib_undistorted/K.json           \
#                 -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts         \
#                 -d Transform_Scan2WV.mat                                \
#                 -d rendered_images/poses/$i/tvecs.json                    \
#                 -d rendered_images/poses/$i/rvecs.json                    \
#                 -o rendered_images/rendered/$i           \
#                 --no-exec                               \
#             "python ../scripts/visualize_poses.py                                \
#                 --intrinsic transforms_camera_calib_undistorted/K.json           \
#                 --extrinsic_folder rendered_images/poses/"$i"           \
#                 --pcd_path data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts --invert_poses \
#                 --T_cloud Transform_Scan2WV.mat                                  \
#                 --headless                                                      \
#                 --outpath rendered_images/rendered/"$i" "          
#     done

#     git add stages/render_random_images
# fi


create_pipeline() {
    if [ -z $1 ]; then echo "please provide batch index"; exit 1; fi

    dvc run -f "stages/render_random_images_scr/render_random_images_scr"$1".dvc"                 \
                -d ../scripts/visualize_poses.py                        \
                -d transforms_camera_calib_undistorted/K_half_scale.json           \
                -d data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts         \
                -d Transform_Scan2WV.mat                                \
                -d rendered_images/poses/$1/tvecs.json                    \
                -d rendered_images/poses/$1/rvecs.json                    \
                -o rendered_images/scene_coords/$1           \
                --no-exec                               \
            "python ../scripts/visualize_poses.py                                \
                --intrinsic transforms_camera_calib_undistorted/K_half_scale.json           \
                --extrinsic_folder rendered_images/poses/"$1"           \
                --pcd_path data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts --invert_poses \
                --T_cloud Transform_Scan2WV.mat                                 \
                --point_size 1                                                  \
                --scene_coord_colors                                            \
                --width 320                                                      \
                --height 180                                                     \
                --headless                                                      \
                --outpath rendered_images/scene_coords/"$1" "   
}


if [ -z $1 ]; then
    printf 'please specify how many batches\n'
elif [ -z $2 ]; then
    printf 'please specify how many images per batch'
else
    NUM_BATCHES="$1"
    NUM_PER_BATCH="$2"

    mkdir -p stages/render_random_images_scr/
    if [[ "$NUM_BATCHES" == 0 ]]; then
        if [ -z $2 ]; then
            echo "please specify batch index"
        else
            BATCH_INDEX="$2"
            create_pipeline $BATCH_INDEX || echo 'broken...'
        fi
    else
        for i in $(seq 0 $[ $NUM_BATCHES - 1 ]); do
            create_pipeline $i || echo 'broken...'
        done
    fi
fi