for FOLDER in data0 data1 data2 
do
	dvc run -f stages/"undistort_""$FOLDER".dvc 			\
			-d transforms_camera_calib                      \
        	-d ../scripts/remap_images_calibrate.py         \
        	-d labeled_images/images/"$FOLDER"             	\
			-o labeled_images/undistorted/"$FOLDER" 		\
	    python ../scripts/remap_images_calibrate.py "labeled_images/images/""$FOLDER""'/*.png'"  \
	                --intrinsic transforms_camera_calib/K.json                  \
	                --dists transforms_camera_calib/dists.json                  \
	                --outpath labeled_images/undistorted/"$FOLDER"      		\
	                --headless                                      			\
	                --exit_when_done

	git add stages/undistort_"$FOLDER".dvc
done

git add labeled_images/undistorted/.gitignore
git add dvc_pipelines/undistort_labeled.sh
