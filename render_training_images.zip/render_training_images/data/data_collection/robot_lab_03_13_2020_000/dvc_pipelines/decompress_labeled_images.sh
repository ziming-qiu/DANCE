dvc pull labeled_images/archive/data0.gz.dvc labeled_images/archive/data1.gz.dvc labeled_images/archive/data2.gz.dvc 

# note: decompress breaks if you put " around this commmand -- need to fix

dvc run -w labeled_images    \
	-f images/data0.dvc  \
	-d archive/data0.gz    \
	-o images/data0                \
    decompress archive/data0.gz

dvc run -w labeled_images    \
	-f images/data1.dvc  \
	-d archive/data1.gz    \
	-o images/data1                \
    decompress archive/data1.gz


dvc run -w labeled_images    \
	-f images/data2.dvc  \
	-d archive/data2.gz    \
	-o images/data2                \
    decompress archive/data2.gz
