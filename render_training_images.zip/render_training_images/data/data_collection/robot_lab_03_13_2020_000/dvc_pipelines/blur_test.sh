for FOLDER in data0 data1 data2 
do
	dvc run -f stages/"blur_test_"$FOLDER.dvc 							\
			-d ../scripts/blur_test.py 								\
			-d labeled_images/images/$FOLDER 							\
			-O labeled_images/blur_test/$FOLDER"_blur_test".json \
		python ../scripts/blur_test.py 								\
				--input_pattern labeled_images/images/$FOLDER/"'*.png'" \
				--output_dir labeled_images/blur_test 							\
				--output_file $FOLDER"_blur_test.json"

	git add stages/blur_test_$FOLDER.dvc
done

git add labeled_images/blur_test/
git add dvc_pipelines/blur_test.sh
git add ../scripts/blur_test.py
