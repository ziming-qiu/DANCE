
# Render using CB Poses
  ![From CB](../../assets/pipelines/render_cb_images_cb.png 'From CB')  


# Render using WV Poses
  ![From WV](../../assets/pipelines/render_cb_images_wv.png 'From WV')  


# Register Pointcloud
  ![Register Data to Calib Scan](../../assets/pipelines/register_pointclouds.png 'register pointclouds')  


# Render WV (labled) Images
  ![Render WV Images](../../assets/pipelines/render_wv_images.png 'render wv images')  


# Blur Test
  ![Blur Test Data 0](../../assets/pipelines/blur_test_data0.png 'blur test data 0')  


 ![Blur Test Data 1](../../assets/pipelines/blur_test_data1.png 'blur test data 1')  


 ![Blur Test Data 2](../../assets/pipelines/blur_test_data2.png 'blur test data 2')  

