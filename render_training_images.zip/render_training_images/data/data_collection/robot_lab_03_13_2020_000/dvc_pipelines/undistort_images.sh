dvc run -f stages/remap_images.dvc 						\
		-d transforms_camera_calib 						\
		-d ../scripts/remap_images_calibrate.py 		\
		-d device_calib_imgs/static_board 				\
		-O transforms_camera_calib_undistorted/K.json	\
		-o device_calib_imgs/undistorted/static_board 	\
	"python ../scripts/remap_images_calibrate.py 'device_calib_imgs/static_board/*.png'  \
				--intrinsic transforms_camera_calib/K.json 					\
				--dists transforms_camera_calib/dists.json 					\
				--outpath device_calib_imgs/undistorted/static_board/      \
				--headless 												\
				--exit_when_done"


git add dvc_pipelines/undistort_images.sh
git add transforms_camera_calib_undistorted
git add stages/remap_images.dvc device_calib_imgs/undistorted/.gitignore
