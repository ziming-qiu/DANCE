dvc run -w data_scan 										  \
	-f data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts.dvc  \
	-d 200313robotlabMerged_redSpotOrigin_noCropping.pts.gz   \
	-o 200313robotlabMerged_redSpotOrigin_noCropping.pts      \
    "decompress 200313robotlabMerged_redSpotOrigin_noCropping.pts.gz"