
dvc run -f stages/convert_from_matlab_cb.dvc                \
        -d from_matlab/calib/cb                         \
        -O from_matlab/calib/converted/cb/tvecs.json    \
    python -c "import numpy as np; import sys; import cv2; import ioutils as io; 
T = np.asarray(io.load('from_matlab/calib/cb/*WvFromCb*.mat')).transpose((2,0,1)); 
R, tvecs = T[:, :3, :3], T[:, :3, 3]; 
pth='from_matlab/calib/converted/cb/'; 
io.save(pth+'rvecs.json', np.asarray([*map(lambda x: cv2.Rodrigues(x)[0], R)])); 
io.save(pth+'tvecs.json', tvecs);"

dvc run -f stages/convert_from_matlab_wv.dvc                \
        -d from_matlab/calib/wv                         \
        -O from_matlab/calib/converted/wv/tvecs.json    \
    python -c "import numpy as np; import cv2; import ioutils as io; 
T = np.asarray(io.load('from_matlab/calib/wv/200408dat_camPoseWvFromHarn.mat')).transpose((2,0,1)) ; 
R, tvecs = T[:, :3, :3], T[:, :3, 3] ; 
pth='from_matlab/calib/converted/wv/' ; 
io.save(pth+'rvecs.json', np.asarray([*map(lambda x: cv2.Rodrigues(x)[0], R)])); 
io.save(pth+'tvecs.json', tvecs) ;"

dvc run -f stages/convert_from_matlab_paths.dvc                 \
        -d from_matlab/calib/200408dat_imageFileNames.mat   \
        -O from_matlab/calib/converted/image_paths.json     \
    python -c "import ioutils as io; from pathlib import Path; 
io.save('from_matlab/calib/converted/image_paths.json', ['_'.join(Path(u[0][0]).name.split(':')) for u in io.load('from_matlab/calib/200408dat_imageFileNames.mat')])"


# git add from_matlab/calib/cb/
# git add from_matlab/calib/wv/

git add dvc_pipelines/convert_from_matlab.sh
git add stages/convert_from_matlab_cb.dvc
git add stages/convert_from_matlab_wv.dvc
git add stages/convert_from_matlab_paths.dvc
git add from_matlab/calib/converted/cb/rvecs.json
git add from_matlab/calib/converted/wv/rvecs.json
git add from_matlab/calib/converted/image_paths.json
git add dvc_pipelines/convert_from_matlab.sh
