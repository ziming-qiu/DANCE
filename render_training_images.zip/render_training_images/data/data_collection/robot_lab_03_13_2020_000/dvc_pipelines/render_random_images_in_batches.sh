#!/bin/bash

create_pipeline() {
    source /root/miniconda3/etc/profile.d/conda.sh
    conda activate data_collection
    if [ -z $1 ]; then echo "please provide batch index"; exit 1; fi

    python ../../scripts/visualize_poses.py                                \
        --intrinsic ../transforms_camera_calib_undistorted/K.json           \
        --extrinsic_folder ../rendered_images/poses/"$1"           \
        --pcd_path ../data_scan/200313robotlabMerged_redSpotOrigin_noCropping.pts --invert_poses \
        --T_cloud ../Transform_Scan2WV.mat                                  \
        --point_size 1                                                  \
        --width 640                                                     \
        --height 360                                                    \
        --headless                                                      \
        --outpath ../rendered_images/rendered/"$1"
}

NUM_BATCHES="$1"


for i in $(seq 999999999 $[ $NUM_BATCHES - 1 + 999999999]); do
    create_pipeline $i &
done

