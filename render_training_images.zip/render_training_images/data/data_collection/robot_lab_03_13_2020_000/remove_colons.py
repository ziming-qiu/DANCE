from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('root_dir', nargs='*', default='.')
args = parser.parse_args()

for pth in Path(args.root_dir).glob('**/*.png'):
	pth.rename('_'.join(str(pth).split(':')))