./data/data_collection/robot_lab_03_13_2020_000/dvc_pipelines/generate_random_poses_batches.sh generates random poses.

./data/data_collection/robot_lab_03_13_2020_000/dvc_pipelines/render_random_images_in_batches.sh and ./data/data_collection/robot_lab_03_13_2020_000/dvc_pipelines/render_random_scene_coord_images_in_batches.sh use the generated random poses to render training images and corresponding scene coordicate labels.

