# NOTE: conda init enables conda in PowerShell
conda init

# Create env data_collection
conda env create --force --file ./data/data_collection/environment.yml

# Set environment variables
conda activate data_collection

# a) This would set the environment variable for PowerShell (i.e., all environents)
#$env:GOOGLE_APPLICATION_CREDENTIALS="gcp_credential.json"
# b) This sets the environment variable only for this environment
#conda env config vars set GOOGLE_APPLICATION_CREDENTIALS="gcp_credential.json"
# c) using the env_vars.bat scripts
cd $env:CONDA_PREFIX
mkdir .\etc\conda\activate.d
mkdir .\etc\conda\deactivate.d
# NOTE: double-double-quote is needed to write double-quote inside a double-quoted string :)
echo "set GOOGLE_APPLICATION_CREDENTIALS=""gcp_credential.json""" | Out-File -FilePath .\etc\conda\activate.d\env_vars.bat
echo "set GOOGLE_APPLICATION_CREDENTIALS=" | Out-File -FilePath .\etc\conda\deactivate.d\env_vars.bat

conda deactivate



# Create env bl
conda env create --force --file ./environment.yml

conda activate bl

cd $env:CONDA_PREFIX
mkdir .\etc\conda\activate.d
mkdir .\etc\conda\deactivate.d
# NOTE: double-double-quote is needed to write double-quote inside a double-quoted string :)
echo "set GOOGLE_APPLICATION_CREDENTIALS=""gcp_credential.json""" | Out-File -FilePath .\etc\conda\activate.d\env_vars.bat
echo "set GOOGLE_APPLICATION_CREDENTIALS=" | Out-File -FilePath .\etc\conda\deactivate.d\env_vars.bat

conda deactivate

