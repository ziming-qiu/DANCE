

if [ ! -z $1 ] && [ "$1" != "headless" ]; then
	printf "\"headless\" is the only valid command line argument\n"
else
	# setting up environment
	source setup/setup_common.sh

	# setup / install open3d + dependencies 

	# https://stackoverflow.com/questions/3466166/how-to-check-if-running-in-cygwin-mac-or-linux
	if [ "$(uname)" == "Darwin" ]; then
	    # Mac OS X platform  
	    if [ "$1" == "headless" ]; then
	    	printf "\nNot implemented yet... currently only support headless rendering in ubuntu.\n\n"
	    else 
	    	source setup/setup_osx.sh
	    fi
	elif [ "$(expr substr $(uname -s) 1 5)" == "Linux" ]; then
	    # GNU/Linux platform
	    
	    if [ "$1" == "headless" ]; then
	    	source setup/setup_headless.sh
	    else
	    	conda activate data_collection
			conda install -c open3d-admin 'open3d=0.9' -y
			conda deactivate
	    fi
	else
		printf "\n Your platform: \n\t$(uname) \nis not supported... trying anyway\n\n"
		conda activate data_collection
		conda install -c open3d-admin 'open3d=0.9' -y
		conda deactivate
	fi

	printf "done.\n\n\n"
fi

