import numpy as np
import itertools

def qrot(q, v):
    """
    https://github.com/facebookresearch/QuaterNet/blob/master/common/quaternion.py
    Rotate vector(s) v about the rotation described by quaternion(s) q.
    Expects a tensor of shape (*, 4) for q and a tensor of shape (*, 3) for v,
    where * denotes any number of dimensions.
    Returns a tensor of shape (*, 3).
    """
    assert q.shape[-1] == 4
    assert v.shape[-1] == 3
    assert q.shape[:-1] == v.shape[:-1]
    
    original_shape = list(v.shape)
    q = q.view(-1, 4)
    v = v.view(-1, 3)
    
    q = q/q.norm(dim=1)[:, None] # project onto unit sphere
    
    qvec = q[:, 1:]
    uv = torch.cross(qvec, v, dim=1)
    uuv = torch.cross(qvec, uv, dim=1)
    return (v + 2 * (q[:, :1] * uv + uuv)).view(original_shape)

def h2e(x):
    '''homogenous to euclidean'''
    d = x.shape[-1]
    return (x / x[:, -1][:, None]) @ torch.eye(d, d-1)

def qinv(q):
    '''quaternion conjugate -- for unit q == inverse rotation'''
    return q * torch.tensor([1.,-1.,-1.,-1.])


def expanded_pairwise_distances(x, y=None):
    '''
    Input: x is a Nxd matrix
           y is an optional Mxd matirx
    Output: dist is a NxM matrix where dist[i,j] is the squared norm between x[i,:] and y[j,:]
            if y is not given then use 'y=x'.
    i.e. dist[i,j] = ||x[i,:]-y[j,:]||^2
    '''
    if y is not None:
         differences = x.unsqueeze(1) - y.unsqueeze(0)
    else:
        differences = x.unsqueeze(1) - x.unsqueeze(0)
    distances = torch.sum(differences * differences, -1)
    return distances



def affine_batch(A, X):
    shape = X.shape
    X = X.reshape(shape[0], -1, shape[-1])
    X = np.concatenate((X, np.ones_like(X[...,-1,None])), axis=-1)
    B = X @ A.transpose((0,2,1))
    return B[...,:shape[-1]].reshape(shape)



#-----------
def get_params(path):
    '''
    read SCR camera / data parameters from file 
    min, ptp, K_img, K_sc, img_mean, sc_mean
    '''
    with open(path) as f:
        s = f.readlines()
        U = [*filter(lambda x:x!='\n', s)]        
        
        (_, minptp_st, _, K_img_st1,K_img_st2,K_img_st3, 
         _, K_sc_st1,K_sc_st2,K_sc_st3, _, img_mean_st, _, sc_mean_st) = filter(lambda x:x!='\n', s)
        
        parsemat = lambda A,B,C : np.asarray([(*map(float, (u[0], u[1], u[2])),) for u in 
                                        itertools.chain(map(lambda x:x.split('\n')[0].split('\t'), 
                                                            (A, B, C)))])
        
        unpack = lambda S: [*map(lambda s:np.asarray([*map(float,s.split(']')[0].split())]), S.split('['))][1:] 

        min, ptp = unpack(minptp_st)
      
        K_img = parsemat(K_img_st1, K_img_st2, K_img_st3)
        K_sc = parsemat(K_sc_st1, K_sc_st2, K_sc_st3)
        
        img_mean, sc_mean = map(lambda s: np.asarray([*map(float, s.split())]), (img_mean_st, sc_mean_st))
        
    return min, ptp, K_img, K_sc, img_mean, sc_mean

import copy
import matplotlib.pyplot as plt

def plot_grid(imgs, nrows, ncols, figsize=(12, 12), transform=lambda x:x):
    imgs = copy.deepcopy(imgs)
    _, axs = plt.subplots(nrows, ncols, figsize=figsize)
    axs = axs.flatten()
    for img, ax in zip(imgs, axs):
        ax.imshow(transform(img))
        ax.axis('off')
    plt.tight_layout()

def view(img, figsize=(12, 6.75)):
    plt.figure(figsize=figsize)
    plt.imshow(img)
    plt.axis('off'); 
    plt.tight_layout()
