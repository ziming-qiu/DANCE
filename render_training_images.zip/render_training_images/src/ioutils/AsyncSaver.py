import threading
import queue
from tqdm import tqdm

import ioutils as io 

# from multiprocessing.pool import ThreadPool

class AsyncSaver(threading.Thread):
    def __init__(self, saver=io.save, max_queue_size=None):
        super(AsyncSaver, self).__init__()
        self.saver = saver
        self.queue = queue.Queue(maxsize=0 if max_queue_size is None else max_queue_size)
        self.done = False
        self.progress_bar = tqdm(total=0, desc='saving: ')

    def run(self):
        # with ThreadPool() as pool:
            # while not (self.done and self.queue.empty()):
                # pool.apply(self.__save_to_disk, self.queue.get())
        while not (self.done and self.queue.empty()):
            path, item, args, kwargs = self.queue.get()
            self.__save_to_disk(path, item, args, kwargs)
                
    def __save_to_disk(self, path, item, args, kwargs):
        # path, item, args, kwargs = arg_tuple
        self.saver(path, item, *args, **kwargs)
        self.progress_bar.update()

    def save(self, path, item, *args, **kwargs):
        if self.done:
            raise RuntimeError('save called after kill')
        
        self.queue.put((path, item, args, kwargs))
        self.progress_bar.total += 1

    def kill(self):
        self.done = True
        self.join()
        self.progress_bar.close()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, type, value, traceback):
        self.kill()
        return True