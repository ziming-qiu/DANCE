import scipy.io
import glob
import numpy as np 
import pathlib 
import json
#save/load

import warnings
import skimage.io
import matplotlib.pyplot as plt
# import tqdm


def save(path, arr, *args, saver=None, **kwargs):
    path = pathlib.Path(path)
    if saver is None:
        # try to guess what saver to use based on extention
        if '.json' in path.name:
            if isinstance(arr, np.ndarray):
                saver = 'json_numpy'
            else:
                saver = 'json'
        elif '.csv' in path.name:
            raise NotImplementedError('TODO: implement csv writer')
        elif any(ext in path.name for ext in ('.jpg', '.jpeg', '.png')):
            saver = '8bit_image'
        elif any(ext in path.name for ext in ('.tif', '.tiff')):
            saver = '32bit_image'
    # lookup the string
    if isinstance(saver, str):
        saver_dict = {
            'json': save_json,
            'json_numpy': lambda *args, **kwargs : save_json(args[0], args[1].tolist()),
            '8bit_image': save_8bit_image,
            '32bit_image': save_32bit_image,
        }
        if saver not in saver_dict:
            raise ValueError(' '.join(('The only default savers are: (', ', '.join(saver_dict.keys()),  
                    ' ) pass your own function or use one of the defaults')))
        
        saver = saver_dict[saver]

    if saver is None:
        raise Exception(f'Can\'t guess saver for \"{path}\"... please provide one.')

    return saver(path, arr, *args, **kwargs)



def load(path, *args, loader=None, **kwargs):
    path_list = [pathlib.Path(p) for p in sorted(glob.glob(str(path)))]
    
    if len(path_list) == 0:
        raise Exception(f'Cound not find any path with the pattern \"{path}\"...')
    elif len(path_list) > 1:
        warnings.warn(f'There is more than one file with the pattern \"{path}\"...')

    # path = pathlib.Path(path_l[0])
    return_data = []
    for path in path_list:
        # try to guess what loader to use based on extention
        if loader is None: 
            if '.json' in path.name:
                loader='json'
            elif '.csv' in path.name:
                raise NotImplementedError('TODO: implement csv reader')
            elif '.mat' in path.name:
                loader='matlab'

        # if loader is a string 
        if isinstance(loader, str):
            loader_dict = {
                'json': load_json,
                'json_numpy': lambda *args, **kwargs : np.asarray(load_json(path, *args, **kwargs)),
                'matlab': load_mat
            }
            if loader not in loader_dict:
                raise ValueError(' '.join((f'"{loader}" is not one of the default loaders: (', 
                    ', '.join(loader_dict.keys()),  ') pass your own function or use one of the defaults.')))
            loader = loader_dict[loader]
        
        if loader is None:
            raise Exception(f'Can\'t guess loader for \"{path}\"... please provide one.')
        
        return_data.append(loader(path, *args, **kwargs))
    
    if len(path_list) == 1:
        return return_data[0]
    else:
        return return_data


def loadT(path, *args, loader=None, **kwargs):
    R = np.asarray(load(pathlib.Path(path) / 'R_*', *args, loader=loader, **kwargs))
    t = np.asarray(load(pathlib.Path(path) / 't_*', *args, loader=loader, **kwargs))

    T = np.eye(4)
    T[:3,:3], T[:3, 3] = R, t.squeeze()

    return T

def save_8bit_image(path, arr, *args, **kwargs):
    return plt.imsave(path, arr, *args, dpi=1, **kwargs)
# def save_8bit_image(path, arr, *args, **kwargs):
    # image = skimage.img_as_ubyte(arr)
    # return skimage.io.imsave(path, np.asarray(image), *args, **kwargs)

def save_32bit_image(path, arr, *args, **kwargs):
    return skimage.io.imsave(path, np.asarray(arr), *args, **kwargs)


def save_json(path, data, *args, **kwargs):
    path = pathlib.Path(path)
    with path.open('w') as f:
        json.dump(data, f, *args, **kwargs)
        
def load_json(path, *args, **kwargs):
    path = pathlib.Path(path)
    with path.open('r') as f:
        X = json.load(f, *args, **kwargs)
    return X

def load_mat(path, *args, **kwargs):
    path = pathlib.Path(path)
    mat_dict = scipy.io.loadmat(path, *args, **kwargs)
    res = [v for k, v in mat_dict.items() if isinstance(v, np.ndarray)]

    if len(res) == 1:
        return res[0]
    else:
        if len(res) == 0: warnings.warn('can\'t find a numpy array to return from matlab. returning mat_dict.', stacklevel=3)
        else: warnings.warn('loading several numpy numpy arrays simultaneously from matlab. returning mat_dict.', stacklevel=3)
        return mat_dict

    # return next(v for k, v in scipy.io.loadmat(path, *args, **kwargs).items() if isinstance(v, np.ndarray))

