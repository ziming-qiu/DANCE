import open3d as o3d 
from pyquaternion import Quaternion
import numpy as np
import scipy
import scipy.spatial
import warnings

import tqdm

RANDOM_SEED = None

def uniform_rejection_sample_random_yxz_rotation(N=1, 
			theta_y=(-np.pi, np.pi), 
			theta_x=(-np.pi, np.pi), 
			theta_z=(-np.pi, np.pi), 
			p=0.5):
	'''actually uniform

		note: the smaller the area you wish to sample over the longer it takes
		theoretically it could never finish.

		YXZ rotation order
	'''

	# TODO: improve this -- handle correctly when range is 0, think more about small ranges
	if ( abs(theta_y[0]-theta_y[1]) < 0.01 or 
		 abs(theta_x[0]-theta_x[1]) < 0.01 or 
		 abs(theta_z[0]-theta_z[1]) < 0.01 	):

		warnings.warn('when one of the ranges is too small this can take too long... --try something else.')

		if 	(	theta_y[0]-theta_y[1] == 0 or
				theta_x[0]-theta_x[1] == 0 or
				theta_z[0]-theta_z[1] == 0 ):
			raise ValueError('one of the ranges has length zero. the function will never return...')


	low, high = zip(theta_y, theta_x, theta_z)

	Rs = None
	pbar = tqdm.tqdm(total=N)
	i = total_generated = 0
	while Rs is None or len(Rs) < N:
		i += 1
		# uniformly sample twice as many rotations as we need
		rotations = scipy.spatial.transform.Rotation.random(num=int(1+N/p), random_state=RANDOM_SEED)
		total_generated += len(rotations)

		# reject rotations that do not satisfy the conditions
		angles = rotations.as_euler('YXZ')
		good = np.logical_and(low <= angles, angles <= high).all(axis=1) 
		new_Rs = rotations[good].as_matrix()
		Rs = new_Rs if Rs is None else np.concatenate((Rs, new_Rs))
		
		pbar.update(len(Rs))
		pbar.set_description(f'{i}th retry - accepted {len(Rs)}/{total_generated} = {100*len(Rs)/total_generated:.3f}%')
		p = (9*p + len(Rs)/total_generated)/10
	pbar.close()
	return Rs[:N]


def random_poses(N = 1, 
					theta_y = (-np.pi, np.pi), 
					theta_x = (-np.pi, np.pi), 
					theta_z = (-np.pi, np.pi), 
					x       = (-1, 1), 
					y       = (-1, 1), 
					z       = (-1, 1),
					initial_rotation = np.eye(3),
					initial_translation = np.zeros(3)
				):
	
	Rs = initial_rotation @ uniform_rejection_sample_random_yxz_rotation(N=N, 
									theta_x=theta_x, theta_y=theta_y, theta_z=theta_z)

	ts = (initial_translation + 
				np.stack([np.random.uniform(a, b, size=N)
									for (a,b) in (x,y,z)], axis=-1))
	
	return Rs, ts

def visualize_poses(Ts):

	o3d.visualization.draw_geometries(
		[
		*(o3d.geometry.TriangleMesh.create_coordinate_frame().transform(T) for T in Ts),
		o3d.geometry.TriangleMesh.create_coordinate_frame(size=4)
		]
	)

def visualize_rotations(Rs):
	Ts = np.zeros((len(Rs), 4,4))
	Ts[:, :3,:3], Ts[:, 3,3] = Rs, 1
	
	visualize_poses(Ts)

if __name__ == '__main__':
	initial_rotation = np.asarray([
			[-1, 0, 0],
			[ 0, 0,-1],
			[ 0,-1, 0],
		])

	# Rs = initial_pose @ uniform_rejection_sample_random_yxz_rotation(
	# 											N = 100, 
	# 											theta_y = (-np.pi, np.pi), 
	# 											theta_x = (-np.pi/12, np.pi/12), 
	# 											theta_z = (-np.pi/12, np.pi/12) )
	
	# t = np.array([0, 3, 1])
	# Ts = np.zeros((len(Rs),4,4))
	# Ts[:, :3,:3], Ts[:, :3, 3], Ts[:, 3,3] = Rs, t, 1

	# visualize_poses(Ts)
	


	Rs, ts = random_poses(
												N = 100, 
												theta_y = (-np.pi, np.pi), 
												theta_x = (-np.pi/16, np.pi/16), 
												theta_z = (-np.pi/16, np.pi/16),
												x       = (-1, 1),
												y       = (-2, 2),
												z       = (0, 2),
												initial_rotation = initial_rotation
												 )
	
	Ts = np.zeros((len(Rs),4,4))
	Ts[:, :3,:3], Ts[:, :3, 3], Ts[:, 3,3] = Rs, ts, 1

	visualize_poses(Ts)




