import torch

import sklearn.metrics as metrics
import matplotlib.pyplot as plt
import numpy as np

import cv2

from pyquaternion import Quaternion

    
def compute_pose(sc_image, background_color, ptp, min, K, xofs=0, yofs=0, 
        PnPSolver=cv2.solvePnPRansac, bg_eps=0.01, **pnp_kwargs):
    '''
    sc_image : Scene Coordinate Image (height x width x 3)
    background_color : Color (3 OR 1)
    ptp : scale factor for sc_image (3 OR 1)
    min : offset for sc_image (3 OR 1)
    K : camera intrinsic matrix (3 x 3)
    xofs : x offset of origin in image
    yofs : y offset of origin in image
    PnPSolver : function with signature 
            ret, rvecs_hat, tvecs_hat, inliers = f(objectPoints, imagePoints, distCoeffs=distCoeffs)
                OR
            ret, rvecs_hat, tvecs_hat = f(objectPoints, imagePoints, distCoeffs=distCoeffs)

    return
        T_hat: Pose Matrix (4 x 4)
        mask: valid pixels mask for sc_image computed from background_color
        inliers: inlier correspondance indecies in sc_image[mask] from PnPSolver
    '''
    sc_image = np.asarray(sc_image)
    # mask = ~((sc_image == background_color[None,None] * np.ones_like(sc_image))).all(axis=-1)
    mask = ~(np.linalg.norm(sc_image - background_color, axis=-1) < bg_eps)
    
    height, width = sc_image.shape[:2]

    sc_points = sc_image[mask].T
    px = (
            np.mgrid[0:height,0:width].transpose(1,2,0)[mask] + 
            np.asarray([yofs, xofs])
        ).T   
    
    objectPoints = sc_points.astype(np.float32).T * ptp + min
    imagePoints = px.astype(np.float32)[(1,0), :].T
    cameraMatrix = K.astype(np.float32)
    distCoeffs = None
    
    res = PnPSolver(objectPoints, imagePoints, 
                            cameraMatrix, distCoeffs=distCoeffs, 
                            **pnp_kwargs)
    if len(res)==4:
        ret, rvecs_hat, tvecs_hat, inliers = res
    elif len(res)==3:
        ret, rvecs_hat, tvecs_hat, inliers = *res, None

    T_hat = np.eye(4)
    T_hat[:3, :3], T_hat[:3, 3] = cv2.Rodrigues(rvecs_hat)[0], tvecs_hat.T
    
    return T_hat, mask, inliers
     
    
    
   




def error_plot(a,b=None,metric=metrics.pairwise.paired_distances, 
    percentiles=[50, 95], units='', mean=True, horiz=True, bins='auto',
    min_err_clip=-float('inf'), max_err_clip=float('inf')):
    '''
        args:
            a : either list of vectors or (iff b is None) list of errors 
            b : either paired list of vectors with a or None -- default=None
            metric : distance function to compare a and b -- default=euclidean
            percentiles : list of percentiles to report -- default=[50, 95]
            units : units to report error in -- default=''
    '''

    errs = a if b is None else metric(a,b)

    if horiz:
        plt.figure(figsize=(14,5))
    else:
        plt.figure(figsize=(10,10))


    for i, cum in enumerate((True, False), start=1):
        if horiz:
            plt.subplot(1,2,i)
        else:
            plt.subplot(2,1,i)


        p, bins, patches = plt.hist(np.clip(errs, min_err_clip, max_err_clip), 
                                    bins=bins, histtype='step',
                                    cumulative=cum, density=True)

        for ptile in percentiles:
            ptile_val = np.percentile(errs, ptile)
            plt.plot([ptile_val]*2, (0,p.max()), 
                     label='{}th % = {:.2f} {}'.format(ptile, ptile_val, units))

        if mean:
            mu = np.clip(errs, min_err_clip, max_err_clip).mean()
            plt.plot((mu,)*2, (0,p.max()), label='mean = {:.2f} {}'.format(mu,units), linestyle='dashed')
            
        plt.title('cdf' if cum else 'pdf')
        plt.legend()
        plt.xlabel('error'+((' (%s)' % units) if units!='' else ''))
        plt.ylabel('P')

        plt.tight_layout()
        
    return errs


def run_model_on_loader(model, test_loader, maxbatches=float('inf')):
    Yhat, Y, M, P = [], [], [], []
    device = next(model.parameters()).device
    with torch.no_grad():
        model.eval()
        for i, (x,y,m,p) in enumerate(test_loader):
            Yhat.append( model(x.to(device))[0].cpu() )
            Y.append(y)
            P.append(p)
            M.append(m)
            if i > maxbatches:
                break
    return torch.cat(Y), torch.cat(Yhat), torch.cat(P), torch.cat(M)
    



# def error_plot(a,b=None,metric=metrics.pairwise.paired_distances, percentiles=[50, 95], units='', mean=True):
#     '''
#         args:
#             a : either list of vectors or (iff b is None) list of errors 
#             b : either paired list of vectors with a or None -- default=None
#             metric : distance function to compare a and b -- default=euclidean
#             percentiles : list of percentiles to report -- default=[50, 95]
#             units : units to report error in -- default=''
#     '''

#     errs = a if b is None else metric(a,b)

#     plt.figure(figsize=(10,4))

#     for i, cum in enumerate((True, False), start=1):
#         plt.subplot(1,2,i)
#         p, bins, patches = plt.hist(errs, bins=19, histtype='step',
#                                    cumulative=cum, density=True)

#         for ptile in percentiles:
#             ptile_val = np.percentile(errs, ptile)
#             plt.plot([ptile_val]*2, (0,p.max()), 
#                      label='{}th % = {:.2f} {}'.format(ptile, ptile_val, units))

#         if mean:
#             mu = errs.mean()
#             plt.plot((mu,)*2, (0,p.max()), label='mean = {:.2f} {}'.format(mu,units), linestyle='dashed')
            
#         plt.title('cdf' if cum else 'pdf')
#         plt.legend()
#         plt.xlabel('error'+((' (%s)' % units) if units!='' else ''))
#         plt.ylabel('P')

