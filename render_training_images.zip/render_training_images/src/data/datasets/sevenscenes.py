import numpy as np
from PIL import Image

# import torch
from torch.utils.data import Dataset

def load_seq(seqpath):
    i = 0
    C,P = [], []
    while True: 
        try:
            path = str(seqpath)+'frame-{:06}.{}'
            color = Image.open(path.format(i, 'color')+'.png').load()
#             color = np.asarray(Image.open(path.format(i, 'color')+'.png'))
            with open(path.format(i, 'pose')+'.txt', 'r') as p:
                pose = np.array(p.read().split(), dtype=np.float32).reshape(4,4)
                
            C.append(color)
            P.append(pose)
            
        except FileNotFoundError as e:
            if i==0:
                raise e
            break
    
        i += 1
        
    return C, np.asarray(P)



class SevenScenesDataset(Dataset):
    def __init__(self, seqpath, transform):
        self.seqpath = seqpath
        self.path = str(seqpath)+'/frame-{:06}.{}'
        self.length = len([*self.seqpath.glob('frame*.color.png')])
        self.transform = transform


    def __getitem__(self, i):
        color = Image.open(self.path.format(i, 'color')+'.png')
#         color = np.asarray(color, dtype=np.float32) / 255

        with open(self.path.format(i, 'pose')+'.txt', 'r') as p:
            pose = np.asarray(p.read().split(), dtype=np.float32).reshape(4,4)

        color = self.transform(color)
        return (color, pose, self.seqpath)

    def __len__(self):
        return self.length
