import numpy as np

from pyquaternion import Quaternion 
from scipy import ndimage
from pathlib import Path
from functools import partial
from torchvision import transforms

import torch
from torch.utils.data import Dataset, DataLoader

import skimage

prep_img = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]), 
 ])
deprep_img = transforms.Compose([
    transforms.Normalize(mean=[0,0,0], std=[1/0.229, 1/0.224, 1/0.225]), 
    transforms.Normalize(mean=[-0.485, -0.456, -0.406], std=[1,1,1]),
    transforms.ToPILImage(),
 ])

prep_lbl = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[.5,.5,.5],
                                 std=[1,1,1]), 
 ])
deprep_lbl = transforms.Compose([
    transforms.Normalize(mean=[0,0,0], std=[1,1,1]), 
    transforms.Normalize(mean=[-0.5, -0.5, -0.5], std=[1,1,1]),
    transforms.ToPILImage(),
 ])



class SCRDataset(Dataset):
    def __init__(self, img_transform=None, lbl_transform=None, root='.', 
                 tags=('rgb', 'scr'), exts=('png', 'tiff'), pathstr='/'+(','.join(('{}',)*7))+'_{}_.{}',
                img_mean=-np.ones(3), sc_mean=-np.ones(3), eps=1e-2, loader=skimage.io.imread):
        
        folder = Path(root) 
        poses = set() 
        for f in folder.iterdir():
            if any(e in f.name for e in exts):
                poses.add((*map(float,f.name.split('_')[0].split(',')),))
        poses = np.array(list(poses))
        self.poses = poses

        self.img_transform = img_transform if img_transform is not None else transforms.ToTensor()
        self.lbl_transform = lbl_transform if lbl_transform is not None else transforms.ToTensor()
        self.pathstr = pathstr
        self.tags = tags 
        self.exts = exts
        self.root = root
        self.eps = eps
        self.loader = loader
        self.img_mean, self.sc_mean = img_mean, sc_mean

    def __getitem__(self, i):
        img, lbl, pose = self.get_image_and_label(i)
                
         # compute mask
#         mask = (((transforms.ToTensor()(img).permute((1,2,0)) - self.sc_mean)**2).sum(dim=-1) < self.eps).numpy()
#         dilate = partial(ndimage.morphology.binary_dilation,
#                         structure=ndimage.generate_binary_structure(2, 2))
        dilate = partial(ndimage.morphology.binary_dilation, iterations=2)
        
#         mask = (skimage.transform.downscale_local_mean(mask, (self.downsampling_factor,self.downsampling_factor)) == 0)
#         mask = torch.from_numpy(mask.astype(np.uint8)).byte()
        
#         print(lbl.shape)
        
        
        # GET RID OF MAGIC NUMBERS! 
        img, lbl = self.img_transform(img).float().contiguous(), self.lbl_transform(lbl).float().contiguous()
        # mask = np.isclose(lbl, (self.sc_mean-(0.485, 0.456, 0.406))[:, None, None], rtol=0, atol=1.5e-1).all(0)
        mask = np.isclose(lbl, self.sc_mean[:, None, None], rtol=0, atol=1.5e-1).all(0)
        mask = dilate(mask)
#         lbl.permute(1,2,0)[~mask] *= 0
    
#         print(lbl.shape)
#         print()
        
        return (
            img, 
            lbl, 
            mask, 
            torch.from_numpy(pose).float()
        )
    
    def get_image_and_label(self, i):
        savestr = self.root+self.pathstr
        sample = [self.loader(savestr.format(*self.poses[i], tag, ext))
                          for (tag, ext) in zip(self.tags, self.exts)]

        t,q = self.poses[i][:3], Quaternion(*self.poses[i][3:])
         
        # constrain to one hemisphere to avoid double cover problem and make mapping injective
        if q.y < 0 or (q.y==0 and (q.x < 0 or (q.x==0 and (q.z < 0 or (q.z==0 and q.w < 0))))):
#             print('flipped', q, 'to', -q)
            q = -q
            
#         print(sample[1].shape)
        return (*sample, np.asarray((*t,*q)))

    def __len__(self):
        return len(self.poses) 


def load_all(datapath, n_max, **kwags):
    D = []
    for i in range(1, n_max):
        try:
            D.append(
                SCRDataset(
                    img_transform=prep_img, 
                    lbl_transform=prep_lbl, 
                    root=datapath+str(i),
                    **kwags
                )
            )
        except FileNotFoundError:
            print(datapath+str(i), 'not found....')
            
    return torch.utils.data.ConcatDataset(D)


def train_val_test_split(dataset, train_p=0.9, val_p=None):
    ''' -- better default would be .8 .1 .1
    

    splits dataset into three disjoit subsets
    train, val, and test of lengths train_p*len(dataset), 
    val_p*len(dataset), and (1-train_p-val_p)*len(dataset)
    respectively. 
    '''
    n = len(dataset)

    assert 0 <= train_p <= 1, 'proportions must be between 0 and 1'
    if val_p is None:
        val_p = 1-train_p

    test_p = 1 - train_p - val_p
    if abs(test_p * n) < 1:
        test_p = 0
    assert test_p >= 0, '{} + {} = {} > 1'.format(train_p, val_p, train_p+val_p)
    

    
    ntrain = np.floor(train_p * n)
    nval = np.ceil(val_p * n)
    ntest = n-ntrain-nval

    train = torch.utils.data.Subset(dataset, np.arange(0,ntrain).astype(int))
    val = torch.utils.data.Subset(dataset, np.arange(ntrain,ntrain+nval).astype(int))
    test = torch.utils.data.Subset(dataset, np.arange(ntrain+nval,n).astype(int))

    return train, val, test



