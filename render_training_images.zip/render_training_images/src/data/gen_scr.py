
'''  
use with this bash function

# generate_dataset root_dir num_folders files_per_folder imwidth imheight lblwidth lblheight
generate_dataset()  { 
	mkdir $1; seq $2 | parallel -n1 --max-procs=2 python gen_scr.py $1/{#} $3 $4 $5 $6 $7\;  \
	cd $1 \; mv {#}/params.txt ./params{#}.txt \; zip -rq {#}.zip {#} \; rm -rf {#}; 
}

generate_dataset scr7 3 50 640 480 80 60

real	1m23.395s
user	3m2.726s
sys	0m12.985s

----

python gen_scr.py scr7/1 150 640 480 80 60 \
&& cd scr7 && mv 1/params.txt ./params.txt && zip -rq 1.zip 1 && rm -rf 1;

real	1m22.894s
user	2m33.464s
sys	0m6.297s

----


generate_dataset scr7 3 1000 640 480 80 60

real	19m30.988s
user	44m11.757s
sys	4m4.574s


----

python gen_scr.py scr8/1 3000 640 480 80 60 && cd scr8 && \
mv 1/params.txt ./params.txt && zip -rq 1.zip 1 && rm -rf 1;

real	23m43.603s
user	46m17.106s
sys	1m54.700s

--

gen2() {
	python gen_scr.py $1/$2 $3 $4 $5 $6 $7 && cd $1 && \
	mv $2/params.txt ./params$2.txt && zip -rq $2.zip $2 && rm -rf $2 && \
	cd ..
}

'''


import pickle

from pathlib import Path

from tqdm import tqdm


import open3d as o3d
import copy
import numpy as np

# import sys
# sys.path.append('../../src')

from data.gen_database import set_pose, to_homo, from_homo, DummyTensor

# from utils import affine_batch

from pyquaternion import Quaternion



# class BatchSaver:
# 	def __init__(self, batch_size, filepath):
# 		self.batch_size = batch_size
# 		self.path = Path(filepath)
# 		self.buffer = []
# 		self.batch_count = 0

# 	def save(self, img, *args):
# 		self.buffer.append(img)

# 		if len(self.buffer) >= batch_size:
# 			f = (self.path / self.batch_count)
# 			picklestring = pickle.dumps(
# 					np.stack((*map(np.asarray, self.buffer), )), 
# 				protocol=pickle.HIGHEST_PROTOCOL)

# 			pickletools.optimize(picklestring)
			
# 			self.buffer = []



def PILsaver(name, img):
	img.save(name)

import skimage.io
default_saver = skimage.io.imsave


######## pull into separate file #########
import itertools 

default_save_path = None 

def gen_database_poses_load(path, poses, savepath=default_save_path, width=224, height=224, point_size=1, 
					geom=False, events=True, render=True,left=100, top=100, to_ram=True,
					visible=False, save=False, saver=default_saver, tag='rgb'):
	
	pcd = o3d.io.read_point_cloud(path)

	
	return gen_database_poses(pcd,poses=poses,savepath=savepath,width=width,height=height,
					point_size=point_size,geom=geom,events=events,render=render,top=top,to_ram=to_ram,
					visible=visible,save=save,saver=saver,tag=tag)


from collections.abc import Iterable
def gen_database_poses(geometries, poses, savepath=default_save_path, width=224, height=224, point_size=1, 
					geom=False, events=True, render=True,left=100, top=100, to_ram=True,
					visible=False, save=False, saver=default_saver, tag='rgb', imgformat='png'):

	'''
	generate a database of (Color, Depth, Pose) for each Pose in poses from the point cloud pcd

	args:
		pcd : o3d PointCloud
		poses : Nx7 array of poses ()
		width : image dimention - default=224
		height : image dimention - default=224
		point_size : size of points - default=5,
		geom : bool o3d update geometry - default=False
		events bool o3d check for events : - default=True
		render bool o3d render : - default=True
		left : position of o3d window - default=100
		top : position of o3d window - default=100
		visible : bool o3d show window - default=False

	returns:
		(I, D, P, K)

		I: np.array(N, width, height, 3) -- color images
		D: np.array(N, width, height, 3) -- depth images
		P: np.array(N, 4, 4)			 -- corresponding poses
		K: o3d.CameraIntrinsic		   -- camera intrinsic

	'''
	rgb = []
	
	vis = o3d.visualization.Visualizer()
	vis.create_window(width=width, height=height, left=left, top=top, visible=visible)
	
	render_option = vis.get_render_option()
	render_option.point_size = point_size
	
	if isinstance(geometries, o3d.geometry.Geometry):
		pcd = geometries
		vis.add_geometry(pcd)
	else:
		try:
			for geometry in geometries:
				vis.add_geometry(geometry)
			pcd = geometries[0]
		except TypeError as e:
			raise e

	idx = 0

	mean_color = np.asarray(pcd.colors).mean(0)
	print(mean_color)

	for t,q in tqdm(zip(*poses), total=len(poses[0])):
		# generate next view
		T = q.transformation_matrix


		# NOTE: -t
		T[:3,3] = (T @ np.asarray([*(-t), 1]))[:3]
		# T[:3,3] = t

		set_pose(vis,T)

		if geom:
			vis.update_geometry()
		if events:
			vis.poll_events()
		if render:
			vis.update_renderer()

		opt = vis.get_render_option()
		opt.background_color = mean_color

		# capture image
		img = vis.capture_screen_float_buffer(False)

		K = vis.get_view_control().convert_to_pinhole_camera_parameters().intrinsic.intrinsic_matrix

		if to_ram:
			rgb.append(img)

		if save:
			if imgformat == 'png':
				img = skimage.img_as_ubyte(img)
			savestr = savepath+'/'+(','.join(('{}',)*7))+'_{}_.{}'
			saver(
				savestr.format(*itertools.chain(*from_homo(T)), tag, imgformat), 
				np.asarray(img)
			)
			idx += 1


	ctr = vis.get_view_control()

	vis.destroy_window()
	

	if to_ram:
		I, P = (
			np.asarray([*map(np.asarray, rgb)]), 
			(np.stack(poses[0]), np.stack(poses[1]))
		)
	else:
		# return objects which just hold the number of images generated
		# as their length -- bit of a hack...
		I = DummyTensor((idx, *np.asarray(img).shape))
		P = DummyTensor((idx, *T.shape))

	return I, P, K, mean_color



from scipy import ndimage 
def gen_scene_coord_dataset(pcd, poses, savepath=default_save_path, imwidth=640, imheight=480, 
				lblwidth=640//8, lblheight=480//8, point_size=1, geom=False, events=True, 
				render=True,left=100, top=100, to_ram=True, visible=False, 
				save=False, saver=default_saver):
		
	# generate images
	I, P1, K_img, mean_img_color = gen_database_poses(pcd, poses, savepath=savepath, width=imwidth, height=imheight, 
					point_size=point_size, geom=geom, events=events, render=render,left=left, 
					top=top, to_ram=to_ram, visible=visible, save=save, saver=saver, tag='rgb', imgformat='png')
	
	# generate scene coord images
	pnts_array = np.asarray(pcd.points)
	min, ptp = pnts_array.min(0), pnts_array.ptp(0)
	SC_colors = (pnts_array-min)/ptp
	pcd.colors = o3d.utility.Vector3dVector(SC_colors)
	
	SC, P2, K_sc, mean_lbl_color = gen_database_poses(pcd, poses, savepath=savepath, width=lblwidth, height=lblheight, 
					point_size=point_size, geom=geom, events=events, render=render,left=left, 
					top=top, to_ram=to_ram, visible=visible, save=save, saver=saver, tag='scr', imgformat='tiff')
	
#	 assert (np.asarray(P1)==np.asarray(poses)).all() and (np.asarray(P2)==np.asarray(poses)).all()
	return I, SC, P2, (min, ptp), K_img, K_sc, mean_img_color, mean_lbl_color


def random_poses_bounds(n, minbound, maxbound):
    ts = np.concatenate([np.random.uniform(low, high,(n,1)) for (low, high) in zip(minbound, maxbound)], axis=1)

    qs = [Quaternion(1,1,0,0) * Quaternion(axis=(0,0,1), radians=theta) 
    			for theta in np.random.uniform(0, 2*np.pi, size=n)]
    
    for i,q in enumerate(qs):
        if q.y < 0 or (q.y==0 and (q.x < 0 or (q.x==0 and (q.z < 0 or (q.z==0 and q.w < 0))))):
            qs[i] = -q

    return np.stack(ts), np.stack(qs)

def random_poses(n, extent, T=np.eye(4)):
	center = T[:3,3]
	ts = ( (np.random.rand(n, 3)-0.5)*extent + center )
	qs = [
		(Quaternion(axis=(0,1,0), radians=(np.random.rand()-0.5)*np.pi*2) *
		Quaternion(axis=(1,0,0), radians=(np.random.rand()-0.5)*np.pi/4)) 
			for i in range(n)]
	for i,q in enumerate(qs):
		if q.y < 0 or (q.y==0 and (q.x < 0 or (q.x==0 and (q.z < 0 or (q.z==0 and q.w < 0))))):
			qs[i] = -q
		
	# Ts = np.stack([q.transformation_matrix for q in qs])
	# Ts[:, :3, 3] = ts

	return np.stack(ts), np.stack(qs)
######## \ pull into separate file #########



# from shutil import rmtree
import argparse


if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Generate SCR dataset')

	parser.add_argument('savepath', help='path to the folder in which to save images')
	parser.add_argument('number', help='number of samples to generate', type=int)
	parser.add_argument('imwidth', help='width of rgb image', type=int)
	parser.add_argument('imheight', help='height of rgb image', type=int)
	parser.add_argument('lblwidth', help='width of scene coord image', type=int)
	parser.add_argument('lblheight', help='height of scene coord image', type=int)
	# parser.add_argument('--para', help='paralellize', default=True, type=bool)

	args = parser.parse_args()

	savepath = Path(args.savepath)
	# rmtree(f)
	savepath.mkdir(parents=True)


	# path = '../../processed/MurrayHill/Mezmeriz/howard_office_mezmeriz_blk360.pts'
	path = '../processed/MurrayHill/Mezmeriz/west_caff_mezmeriz_blk360.pts'
	# path = '../Mezmeriz/bell2/Bell2.pts'


	# poses = random_poses(args.number, 1.5)
	poses = random_poses_bounds(args.number, (0,0,-0.2), (9,20,0.2))

	pcd = o3d.io.read_point_cloud(path)
	I, SC, P2, (min, ptp), K_img, K_sc,  mean_img_color, mean_lbl_color = gen_scene_coord_dataset(
				  pcd, poses, savepath=args.savepath, 
				  imwidth=args.imwidth, imheight=args.imheight, lblwidth=args.lblwidth, lblheight=args.lblheight, 
				  point_size=1.25, geom=False, events=True, render=True, left=100, top=100, 
				  to_ram=False, visible=False, save=True, saver=default_saver)


	print(I.shape, SC.shape, P2.shape)
	param_str = ('\n'.join((
						'min\tptp\n{}\t{}\n', 'intrinsic matrix (K_img):',
					  	('{}\t'*3+'\n')*3,
					  	'intrinsic matrix (K_sc):',
					  	('{}\t'*3+'\n')*3,
					  	'\nimg_mean:\n{}\t{}\t{}\n',
					  	'sc_mean:\n{}\t{}\t{}\n',
					  	 ))
					  ).format(
					  	min, ptp, *itertools.chain(*K_img), *itertools.chain(*K_sc), 
					  			*mean_img_color, *mean_lbl_color)

	print(param_str)

	param_file = savepath / 'params.txt'
	param_file.touch()
	with param_file.open(mode='w') as f:
		f.write(param_str)

	

