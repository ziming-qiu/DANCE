import numpy as np
import open3d as o3d
from pyquaternion import Quaternion


import itertools
import functools

import matplotlib.pyplot as plt # to save images 
default_saver = functools.partial(plt.imsave, dpi=1)


def set_pose(vis, T):
    '''
    set the pose of the camera in an Open3d Visualizer
    args:
        vis : o3d Visualizer
        T : homogeneous transform matrix

    returns:
        T : homogeneous transform matrix
    '''
    ctr = vis.get_view_control()
    pose = ctr.convert_to_pinhole_camera_parameters()
    # print(T)
    pose.extrinsic = T
    ctr.convert_from_pinhole_camera_parameters(pose)
    

def to_homo(t,q):
    '''
    args:
        t : postition vector
        q : orientaion quaternion

    returns:
        T : homogeneous transform matrix
    '''
    T = q.transformation_matrix
    T[:3, 3] = np.asarray(t).transpose() 
    return T

def from_homo(T):
    '''
    args:
        T : homogeneous transform matrix

    returns:
        t : postition vector
        q : orientaion quaternion
    '''
    t = T[:3, 3]
    q = Quaternion(matrix=T)

    # constrain to one hemisphere to avoid double cover problem and make mapping injective
    if q.y < 0 or (q.y==0 and (q.x < 0 or (q.x==0 and (q.z < 0 or (q.z==0 and q.w < 0))))):
        q = -q

    return t, q


def set_basis(pcd, 
    positional_offset=np.asarray([-0.535, -0.66, 0.225]), 
    angular_offset=Quaternion(axis=[0,0,1], degrees=42) ):
    '''
    for now hardcoded parameters for Howard's office. Need to fix this.
    '''

    # center data (put origin at centroid)
    T = to_homo(-np.asarray(pcd.points).mean(axis=0), Quaternion(1,0,0,0))
    pcd.transform(T)

    # rotate to align axis with walls
    T = to_homo(np.zeros(3), angular_offset)
    pcd.transform(T)

    # align corner to origin (origin @ min)
    T = to_homo(-pcd.get_min_bound(), Quaternion(1,0,0,0))
    pcd.transform(T)

    # manual offset
    T = np.eye(4)
    T[:3, 3] = positional_offset
    pcd.transform(T)
    
    return pcd





def gen_database(pcd, center, extent, steps=10, width=224, height=224, point_size=5, 
                    geom=False, events=True, render=True,left=100, top=100, to_ram=True,
                    visible=False, save=False, saver=default_saver):

    '''
    generate a database of images evenly spaced throught a cube from a point cloud

    args:
        pcd : o3d PointCloud
        center : 4x4 homogeneous transform matrix denoting the center of the cube
        extent : float the size of the cube in meters
        steps : number of discrete positions per side (will generate a total of steps^3 images)  - default=10
        width : image dimention - default=224
        height : image dimention - default=224
        point_size : size of points - default=5,
        geom : bool o3d update geometry - default=False
        events bool o3d check for events : - default=True
        render bool o3d render : - default=True
        left : position of o3d window - default=100
        top : position of o3d window - default=100
        visible : bool o3d show window - default=False

    returns:
        database, poses

        database: np.array(steps^3, width, height, 3) -- image database
        poses: np.array(steps^3, 4, 4)             -- corresponding poses

    '''
    database, poses = [], []
    
    vis = o3d.Visualizer()
    vis.create_window(width=width, height=height, left=left, top=top, visible=visible)
    
    render_option = vis.get_render_option()
    render_option.point_size = point_size
    
    vis.add_geometry(pcd)
    
    set_pose(vis,center)
    T = center.copy()
    
    t = center[:3, 3]
    
    vis.update_geometry()
    vis.poll_events()
    vis.update_renderer()

    savestr = 'image/'+(','.join(('{}',)*7))+'_.png'
    idx = 0
    for t0 in np.linspace(t[0]-extent/2, t[0]+extent/2, steps):
        for t1 in np.linspace(t[1]-extent/2, t[1]+extent/2, steps):
            for t2 in np.linspace(t[2]-extent/2, t[2]+extent/2, steps):
                # capture image
                # vis.capture_depth_float_buffer(False)
                img = vis.capture_screen_float_buffer(False)

                if to_ram:
                    database.append(img)
                    poses.append(T.copy())

                if save:
                    saver(
                        savestr.format(*itertools.chain(*from_homo(T))), 
                        img
                    )
                    idx += 1

                
                # generate next view
                T[:3, 3] = np.asarray([t0, t1, t2])
                set_pose(vis,T)
                
                if geom:
                    vis.update_geometry()
                if events:
                    vis.poll_events()
                if render:
                    vis.update_renderer()

    vis.destroy_window()
    

    if to_ram:
        D, Y = np.asarray([*map(np.asarray, database)]), np.stack(poses)
    else:
        # return objects which just hold the number of images generated
        # as their length -- bit of a hack...
        D = DummyTensor((idx, *np.asarray(img).shape))
        Y = DummyTensor((idx, *T.shape))
    return D, Y



###################################################################################################

class DummyTensor(object):
    def __init__(self, shape):
        self.shape=shape
    def __len__(self):
        return self.shape[0]
    def __getitem__(self, idx):
        raise NotImplementedError('This is a dummy object, which only holds a shape but no data.')
    def __setitem__(self, idx, val):
        raise NotImplementedError('This is a dummy object, which only holds a shape but no data.')
    @property
    def ndim(self):
        return len(self.shape)

def cat(*args, **kwargs):
    # print(type(args[0]))
    if type(args[0]) is DummyTensor:
        assert all(args[0].shape[1:]==dt.shape[1:] for dt in args), 'all DummyTensors must have same shape except for first dim'
        if len(kwargs) > 0: raise NotImplementedError('no kwargs implemented yet')

        return DummyTensor((sum(dt.shape[0] for dt in args), *args[0].shape[1:]))
    else:
        return np.concatenate(args, **kwargs)

################################# multiprocess version ##########################################

import multiprocessing as mp

def load_cloud_and_gen_database(path, width=224, height=224, point_size=5, 
                                geom=False, events=True, render=True, 
                                extent=1, steps=10, center=np.eye(4), left=250, top=250, 
                                visible=False, save=False, saver=default_saver, to_ram=False):
    
    pcd = o3d.read_point_cloud(path)
    pcd = set_basis(pcd)
    
    return gen_database(pcd, center, extent, steps, width, height, 
                  point_size, geom, events, render, left, top, visible=visible, save=save, saver=saver)
    

def map_func(path, width, height, point_size, 
                                geom, events, render, extent, steps, args, 
                                visible=False, save=False, saver=default_saver, to_ram=False):
    
    return load_cloud_and_gen_database(path, width, height, point_size, 
                                geom, events, render, extent, steps, *args, 
                                visible=visible, save=save, saver=saver, to_ram=to_ram)

def gen_database_div(path, center, extent, steps=10, width=224, height=224, point_size=5,visible=False,
                    geom=False, events=True, render=True,left=200,top=200, f=map_func, workers=-1, 
                    save=False, saver=default_saver, to_ram=False):
    
    assert steps % 2 == 0, 'steps should be an even number'
    
    t = center[:3, 3]
    
    centers = [
                (x,y,z) for x in (t[0]-extent/4, t[0]+extent/4)
                          for y in (t[1]-extent/4, t[1]+extent/4)
                                for z in (t[2]-extent/4, t[2]+extent/4)
              ]
    
    Ts = []
    for (t0, t1, t2) in centers:
        T = center.copy()
        T[:3, 3] = np.asarray([t0, t1, t2])
        Ts.append(T)
    
   
    F = functools.partial(f, path, width, height, point_size, 
                        geom, events, render, extent/2, steps//2, visible=visible, save=save, saver=saver, to_ram=to_ram)
    
    args = zip(Ts, [left+i%4*width for i in range(len(Ts))], [top+i//4*height for i in range(len(Ts))])

    data = []
    with (mp.Pool() if workers==-1 else mp.Pool(workers)) as pool:
        for partial_result in pool.imap_unordered(F, args):
            data.append(partial_result)

    database, poses = [*map(cat, zip(*data))]

    return database, poses











################################################################################################################

default_save_path = '../data/MurrayHill/HowardOffice/rendered'

def gen_database_poses(pcd, poses, savepath=default_save_path, width=224, height=224, point_size=5, 
                    geom=False, events=True, render=True,left=100, top=100, to_ram=True,
                    visible=False, save=False, saver=default_saver):

    '''
    generate a database of (Color, Depth, Pose) for each Pose in poses from the point cloud pcd

    args:
        pcd : o3d PointCloud
        poses : Nx7 array of poses ()
        width : image dimention - default=224
        height : image dimention - default=224
        point_size : size of points - default=5,
        geom : bool o3d update geometry - default=False
        events bool o3d check for events : - default=True
        render bool o3d render : - default=True
        left : position of o3d window - default=100
        top : position of o3d window - default=100
        visible : bool o3d show window - default=False

    returns:
        (I, D, P, K)

        I: np.array(N, width, height, 3) -- color images
        D: np.array(N, width, height, 3) -- depth images
        P: np.array(N, 4, 4)             -- corresponding poses
        K: o3d.CameraIntrinsic           -- camera intrinsic

    '''
    rgb, depth_y = [], []
    
    vis = o3d.Visualizer()
    vis.create_window(width=width, height=height, left=left, top=top, visible=visible)
    
    render_option = vis.get_render_option()
    render_option.point_size = point_size
    
    if isinstance(pcd, o3d.Geometry):
        vis.add_geometry(pcd)
    else:
        for p in pcd:
            vis.add_geometry(p)

    savestr = savepath+'/'+(','.join(('{}',)*7))+'_{}_.png'
    idx = 0
#     print(poses.shape)
    for T in poses:
#         print(T.shape)
        # generate next view
        #         T[:3, 3] = np.asarray([t0, t1, t2])
        set_pose(vis,T)

        if geom:
            vis.update_geometry()
        if events:
            vis.poll_events()
        if render:
            vis.update_renderer()



        # capture image
        depth = vis.capture_depth_float_buffer(False)
        img = vis.capture_screen_float_buffer(False)

        if to_ram:
            rgb.append(img)
            depth_y.append(depth)
#             pose_y.append(T.copy())

        if save:
            saver(
                savestr.format(*itertools.chain(*from_homo(T)), 'rgb'), 
                img
            )
            saver(
                savestr.format(*itertools.chain(*from_homo(T)), 'depth'), 
                depth
            )
            idx += 1


    ctr = vis.get_view_control()
    pose = ctr.convert_to_pinhole_camera_parameters()
    K = pose.intrinsic
        
    vis.destroy_window()
    

    if to_ram:
        I, D, P = (
            np.asarray([*map(np.asarray, rgb)]), 
            np.asarray([*map(np.asarray, depth_y)]),
            np.stack(poses)
        )
    else:
        # return objects which just hold the number of images generated
        # as their length -- bit of a hack...
        I = DummyTensor((idx, *np.asarray(img).shape))
        D = DummyTensor((idx, *np.asarray(depth).shape))
        P = DummyTensor((idx, *T.shape))

    return I, D, P, (K.intrinsic_matrix, K.width, K.height)



def random_positions(n, T, extent):
    mu, std = T[:3, 3], extent
    ts = ( (np.random.rand(n, 3)-0.5)*std + mu )
    Ts = np.stack([T]*n)
    Ts[:, :3, 3] = ts
    return Ts




def gen_database_poses_and_load(poses, path, savepath=default_save_path, 
                    width=224, height=224, point_size=5, geom=False, events=True, render=True,
                    left=100, top=100, to_ram=True, visible=False, save=False, saver=default_saver):
    
            
    pcd = o3d.read_point_cloud(path)
    # pcd = set_basis(pcd)
    
    return gen_database_poses(poses=poses, savepath=savepath, pcd=pcd, width=width, height=height, point_size=point_size, 
                    geom=geom, events=events, render=render,left=left, top=top, to_ram=to_ram,
                    visible=visible, save=save, saver=saver)
    
    
    
    

def gen_database_poses_para(path, poses, savepath=default_save_path, 
                    width=224, height=224, point_size=5, geom=False, events=True, 
                    render=True,left=100, top=100, to_ram=True, visible=False, 
                    save=False, saver=default_saver, workers=4):
    
    f = functools.partial(gen_database_poses_and_load, path=path, savepath=savepath, width=width, height=height, point_size=point_size, 
                    geom=geom, events=events, render=render,left=left, top=top, to_ram=to_ram,
                    visible=visible, save=save, saver=saver)
    
    I, D, P = [], [], []
#     print(poses.shape)
    with mp.Pool(workers) as pool:
        for img,depth,pose,K in pool.imap_unordered(f, poses.reshape(4, -1, 4, 4)):
            I.append(img)
            D.append(depth)
            P.append(pose)
            
    return cat(*I), cat(*D), cat(*P), K
        
        



