import open3d as o3d
import ioutils as io
import numpy as np
import warnings

def configure_vis_window(vis, intrinsic=None, background_color=None, point_size=None):
	ctl = vis.get_view_control()
	params = ctl.convert_to_pinhole_camera_parameters()
	width, height = params.intrinsic.width, params.intrinsic.height

	if intrinsic is not None:
		K_ld = np.asarray(io.load(intrinsic))
		K = params.intrinsic.intrinsic_matrix
		ctr, ctr_ld = K[:2, 2], K_ld[:2, 2]
		if not np.allclose(ctr, ctr_ld):
			warnings.warn('Open3D currently only supports changing focal length -- cx and cy are always in the center of the image.', stacklevel=2)
		if K[0, 1] != 0:
			warnings.warn('Open3D currently only supports changing focal length -- skew is always zero.', stacklevel=2)
		
		fx_ld, fy_ld, _ = np.diag(K_ld)

		params.intrinsic = o3d.camera.PinholeCameraIntrinsic(width, height, fx_ld, fy_ld, *ctr)
		ctl.convert_from_pinhole_camera_parameters(params)

	if background_color is not None:
		opt = vis.get_render_option()
		opt.background_color = background_color
	
	if point_size is not None:
		opt = vis.get_render_option()
		opt.point_size = point_size


def set_pose(vis, R_or_T, t=None):
	T = R_or_T
	if t is not None:
		T = np.eye(4)
		T[:3,:3], T[:3, 3], T[3,3] = R_or_T, t, 1
			
	ctr = vis.get_view_control()
	pose = ctr.convert_to_pinhole_camera_parameters()
	pose.extrinsic = T
	ctr.convert_from_pinhole_camera_parameters(pose)


def get_pose(vis):
	ctr = vis.get_view_control()
	params = ctr.convert_to_pinhole_camera_parameters()
	return params.extrinsic



