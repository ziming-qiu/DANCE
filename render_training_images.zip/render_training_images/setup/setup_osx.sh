# printf "\ncreating/updating environment...\n\n"

# conda env create --force --file environment.yml
# conda env create --force --file data/data_collection/environment.yml
# printf "finished creating/updating environment.\n\n"

# source setup_common.sh
# conda install --name data_collection --file data/data_collection/environment_headless.yml
# conda activate data_collection
# conda env update --file data/data_collection/environment.yml
# conda deactivate


# setup conda env
# conda create --force --name data_collection python=3.6 -y
# source setup_common.sh

MAC_OS_VERSION=$(sw_vers | grep ProductVersion | cut -f2 | cut -d'.' -f'2')
if [ $MAC_OS_VERSION -lt 15 ]; then
	pushd .

	# check if we already have the binary
	BIN_PATH=$(find . -name open3d-0.9.0.0-py36_0.tar.bz2)
	if [ $BIN_PATH ]; then 
		printf "installing open3d from prebuilt binary\n"
	else
		# build the binary if we don't find it
		printf "\ncompiling open3d...\n"
		# build open3d
		pushd .
		source setup/build_osx.sh

		conda activate data_collection
		make conda-package
		conda deactivate
		popd
	fi

	conda activate data_collection
	conda install --use-local $(find . -name open3d-0.9.0*.tar.bz2) -y # install locally compiled o3d
else
	conda activate data_collection
	conda install -c open3d-admin 'open3d=0.9' -y
fi

# add view_graph to environment
printf '\n# added by setup_osx.sh \nview_graph() { make_graph $1 | open -a Preview.app -f; };\nexport -f view_graph;\n' >> $CONDA_PREFIX/etc/conda/activate.d/env_vars.sh
printf '\n# added by setup_osx.sh \nunset view_graph' >> $CONDA_PREFIX/etc/conda/deactivate.d/env_vars.sh

conda deactivate

printf "done.\n\n\n"
