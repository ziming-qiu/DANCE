conda activate data_collection

# git clone --recursive https://github.com/intel-isl/Open3D     # will revert to this (possibly pinned to a specific commit)
git clone --recursive git@github.com:JackLangerman/Open3D.git   # temporary -- only changes are small formatting tweaks to allow compilation on OS X 10.13 + Ubuntu

cd Open3D
bash util/scripts/install-deps-osx.sh assume-yes


mkdir build && cd build

# cmake -DPYTHON_EXECUTABLE:FILEPATH=/usr/local/bin/python3 	\
# 	  -DPYTHON_LIBRARY:FILEPATH=/usr/local/Cellar/python/$(python3 -V | cut -d' ' -f2)/Frameworks/Python.framework/Versions/3.6/lib/libpython3.6m.dylib \
# 	  ..

# cmake -DPYTHON_EXECUTABLE:FILEPATH=/usr/local/bin/python3 	\
	  # -DPYTHON_LIBRARY:FILEPATH=/usr/local/Cellar/python/$(python3 -V | cut -d' ' -f2)/Frameworks/Python.framework/Versions/3.6/lib/libpython3.6m.dylib \
	  # ..

cmake -DPYTHON_EXECUTABLE:FILEPATH=$(which python)	\
	  -DPYTHON_LIBRARY:FILEPATH=$CONDA_PREFIX/lib/libpython3.6m.dylib \
	  ..
# cmake ..

make -j
conda deactivate
