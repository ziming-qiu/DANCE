unset GOOGLE_APPLICATION_CREDENTIALS
unset PYTHONPATH
unset compress
unset decompress
unset make_graph
unset save_graph
unset REPO_ROOT
