# setup data_collection environment
printf "\nsetting up data_collection environment...\n"

conda create --force --name data_collection python=3.6 -y
conda activate data_collection

#conda env create --force --file data/data_collection/environment.yml
conda env update --file data/data_collection/environment.yml

# install dvc/git hooks to git repo
dvc install

REPO_ROOT=$(git rev-parse --show-toplevel)

# setup environment variables
mkdir -p $CONDA_PREFIX/etc/conda/activate.d
mkdir -p $CONDA_PREFIX/etc/conda/deactivate.d 

printf "export REPO_ROOT=$REPO_ROOT # added by setup_common.sh\n" > .tmp_activate
cat setup/env_vars_activate.sh >> .tmp_activate

mv .tmp_activate $CONDA_PREFIX/etc/conda/activate.d/env_vars.sh
cp setup/env_vars_deactivate.sh $CONDA_PREFIX/etc/conda/deactivate.d/env_vars.sh


# printf "\nadding gcp credential to environment...\n"
# setup_env_var GOOGLE_APPLICATION_CREDENTIALS $REPO_ROOT/gcp_credential.json

# printf "\nsetting up PYTHONPATH to environment...\n"
# setup_env_var PYTHONPATH $REPO_ROOT/src


# printf "\nadding compress/decompress to environment...\n"

# pushd $CONDA_PREFIX
# echo 'compress() { tar -c $1 | tqdm --bytes --total $[512 * $(du -s $1 | cut -f1)] | pigz > $2; }' >>  etc/conda/activate.d/env_vars.sh
# echo 'decompress() { pigz -dc $1 | tqdm --bytes --total $(pigz -l $1 | tail -n1 | tr -s [:blank:] \\t | tr -d \? | cut -f1) | tar xf - ; }' >>  etc/conda/activate.d/env_vars.sh
# echo 'make_graph() { dvc pipeline show "$1" --dot | dot -Tpng; } # $1=path/to/some_stage.dvc'
# echo 'save_graph() { make_graph "$1" > "$2"; } # $1=path/to/some_stage.dvc, $2=path/to/somestage.png'
# echo 'export -f compress;' >>  etc/conda/activate.d/env_vars.sh
# echo 'export -f decompress;' >>  etc/conda/activate.d/env_vars.sh
# echo 'export -f make_graph;' >>  etc/conda/activate.d/env_vars.sh
# echo 'export -f save_graph;' >>  etc/conda/activate.d/env_vars.sh
# popd

printf "\ndone setting up data_collection environment...\n"

conda deactivate

