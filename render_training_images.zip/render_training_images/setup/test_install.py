


if __name__ == '__main__':
	print('importing open3d', flush=True)
	import open3d as o3d 

	print('creating geometry', flush=True)
	geo = o3d.geometry.TriangleMesh.create_coordinate_frame()

	print('creating Visualizer', flush=True)
	vis = o3d.visualization.Visualizer()

	print('creating window', flush=True)
	vis.create_window(width=640, height=360, window_name='Test Window')

	print('adding geometry to Visualizer', flush=True)
	vis.add_geometry(geo)

	print('capturing image', flush=True)
	import numpy as np 
	img = np.asarray( vis.capture_screen_float_buffer(do_render=True) )

	print('getting $REPO_ROOT from environment', flush=True)
	import os
	import pathlib
	root = pathlib.Path(os.environ['REPO_ROOT'])

	print('saving image', flush=True)
	import ioutils as io 
	io.save(root / 'setup' / 'test_img2.png', img)

	print('loading image to compare', flush=True)
	import skimage.io 

	img = io.load(root / 'setup' / 'test_img.png', loader=skimage.io.imread)
	img2 = io.load(root / 'setup' / 'test_img2.png', loader=skimage.io.imread)

	if np.allclose(img, img2):
		print('\n -> passed test... <-', flush=True)
	else:
		raise Exception('it seemed like everything worked but the images do not match...')