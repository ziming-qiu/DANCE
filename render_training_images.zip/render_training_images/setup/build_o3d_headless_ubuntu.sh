
# update packages
sudo apt-get update -y
sudo apt-get upgrade -y

# ROLLED BACK TO 3.6
# install python3.7 # needs to be run before this.
# sudo apt update
# sudo apt install software-properties-common
# sudo add-apt-repository ppa:deadsnakes/ppa
# sudo apt install python3.7
# python3.7 -m pip install pip

 
# install OSMesa
sudo apt-get install libosmesa6-dev -y

# setup virtualenv
# sudo apt-get install virtualenv python3-pip -y
sudo apt-get install virtualenv -y

virtualenv -p /usr/bin/python3 py3env

# enter python env
source py3env/bin/activate

###
# install numpy / matplotlib
pip install numpy matplotlib

# download Open3D v0.9.0 source
# git clone --recursive -b "v0.9.0" https://github.com/intel-isl/Open3D Open3D
# git clone --recursive https://github.com/intel-isl/Open3D     # will revert to this (possibly pinned to a specific commit)
git clone --recursive git@github.com:JackLangerman/Open3D.git   # temporary -- only changes are small formatting tweaks to allow compilation on OS X 10.13 + Ubuntu
cd Open3D/


# install deps
sudo apt-get install cmake -y
bash util/scripts/install-deps-ubuntu.sh assume-yes
# sudo apt-get install -y nasm

# make build folder
mkdir -p build && cd build


# configure build
cmake -DENABLE_HEADLESS_RENDERING=ON \
           -DBUILD_GLEW=ON \
           -DBUILD_GLFW=ON \
           -DPYTHON_EXECUTABLE:FILEPATH=$(which python) \
           -DPYTHON_LIBRARY:FILEPATH=/usr/lib/x86_64-linux-gnu/libpython3.6m.so \
           ..

# compile
# make
make -j

# build python lib
# make install-pip-package

deactivate

# make conda-package






# cd 

# sudo apt update
# sudo apt ugragde
# sudo apt-get install libosmesa6-dev
# sudo apt-get install virtualenv python3-pip
# virtualenv -p /usr/bin/python3 py3env
# source py3env/bin/activate
# pip install numpy matplotlib

# git clone git@github.com:intel-isl/Open3D.git
# cd Open3D/
# mkdir build && cd build


# cmake -DENABLE_HEADLESS_RENDERING=ON \
#       -DBUILD_GLEW=ON \
#       -DBUILD_GLFW=ON \
#       -DPYTHON_EXECUTABLE:FILEPATH=/usr/bin/python3 \
#       
