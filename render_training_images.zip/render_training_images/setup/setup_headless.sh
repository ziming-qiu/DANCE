# printf "\ncreating/updating environment...\n\n"
  
# # conda env create --force --file environment.yml
# conda env create --force --file data/data_collection/environment_headless.yml
# printf "finished creating/updating environment.\n\n"

# setup conda env
# conda create --force --name data_collection python=3.6 -y
# source setup_common.sh



pushd .

# check if we already have the binary
BIN_PATH=$(find . -name open3d-0.9.0*.tar.bz2)
if [ $BIN_PATH ]; then 
	printf "installing open3d from prebuilt binary\n"
else
	# build the binary if we don't find it
	printf "\ncompiling open3d...\n"
	# build open3d
	pushd .
	source setup/build_o3d_headless_ubuntu.sh

	conda activate data_collection
	make conda-package
	conda deactivate
	popd
fi

conda activate data_collection
conda install --use-local $(find . -name open3d-0.9.0*.tar.bz2) -y # install locally compiled o3d

cd ../..
rm -rf py3env

printf "done.\n\n\n"
