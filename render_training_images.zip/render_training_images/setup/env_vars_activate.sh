

export GOOGLE_APPLICATION_CREDENTIALS=$REPO_ROOT/gcp_credential.json

export PYTHONPATH=$REPO_ROOT/src


# convenience functions
compress() { tar -c $1 | tqdm --bytes --total $[512 * $(du -s $1 | cut -f1)] | pigz > $2; }
decompress() { pigz -dc $1 | tqdm --bytes --total $(pigz -l $1 | tail -n1 | tr -s [:blank:] \\t | tr -d \? | cut -f1) | tar xf - ; }

# $1=path/to/some_stage.dvc
make_graph() { dvc pipeline show "$1" --dot | dot -Tpng; } 

# $1=path/to/some_stage.dvc, $2=path/to/somestage.png
save_graph() { make_graph "$1" > "$2"; } 

export -f compress 
export -f decompress
export -f make_graph
export -f save_graph